package net.acidicts.poweredtools.recipe.recycler;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.acidicts.poweredtools.block.ModBlocks;
import net.acidicts.poweredtools.recipe.ModRecipes;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.recipe.*;

public record RecyclerRecipe(class_1856 inputItem, class_1799 output, int cookingTime) implements class_1860<RecyclerRecipeInput> {
    @Override
    public class_2371<class_1856> method_8117() {
        class_2371<class_1856> list = class_2371.method_10211();
        list.add(this.inputItem);

        return list;
    }

    @Override
    public class_1799 method_17447() {
        return new class_1799(ModBlocks.RECYCLER);
    }

    public int getCookingTime() {
        return cookingTime;
    }

    @Override
    public boolean matches(RecyclerRecipeInput input, class_1937 world) {
        if (world.field_9236) {
            return false;
        }

        return inputItem.method_8093(input.method_59984(0));
    }

    @Override
    public class_1799 craft(RecyclerRecipeInput input, class_7225.class_7874 lookup) {
        return output.method_7972();
    }

    @Override
    public boolean method_8113(int width, int height) {
        return true;
    }

    @Override
    public class_1799 method_8110(class_7225.class_7874 registriesLookup) {
        return output;
    }

    @Override
    public class_1865<?> method_8119() {
        return ModRecipes.RECYCLER_SERIALIZER;
    }

    @Override
    public class_3956<?> method_17716() {
        return ModRecipes.RECYCLER_TYPE;
    }

    public static class Serializer implements class_1865<RecyclerRecipe>{

        public static final MapCodec<RecyclerRecipe> CODEC = RecordCodecBuilder.mapCodec(inst -> inst.group(
                class_1856.field_46096.fieldOf("ingredient").forGetter(RecyclerRecipe::inputItem),
                class_1799.field_24671.fieldOf("output").forGetter(RecyclerRecipe::output),
                com.mojang.serialization.Codec.INT.fieldOf("cookingtime").forGetter(RecyclerRecipe::cookingTime)
        ).apply(inst, RecyclerRecipe::new));

        public static final class_9139<class_9129, RecyclerRecipe> STREAM_CODEC =
                class_9139.method_56436(
                        class_1856.field_48355, RecyclerRecipe::inputItem,
                        class_1799.field_48349, RecyclerRecipe::output,
                        class_9139.method_56437((buf, value) -> buf.method_53002(value), buf -> buf.readInt()), RecyclerRecipe::cookingTime,
                        RecyclerRecipe::new
                );

        @Override
        public MapCodec<RecyclerRecipe> method_53736() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, RecyclerRecipe> method_56104() {
            return STREAM_CODEC;
        }
    }
}
