package net.acidicts.poweredtools.recipe.alloy_smelter;

import net.minecraft.class_1799;
import net.minecraft.class_9695;

public record AlloySmelterRecipeInput(class_1799 input1, class_1799 input2, class_1799 input3) implements class_9695 {
    @Override
    public class_1799 method_59984(int slot) {
        return switch (slot) {
            case 0 -> input1;
            case 1 -> input2;
            case 2 -> input3;
            default -> throw new IllegalArgumentException("Recipe does not contain slot " + slot);
        };
    }

    @Override
    public int method_59983() {
        return 3;
    }
}
