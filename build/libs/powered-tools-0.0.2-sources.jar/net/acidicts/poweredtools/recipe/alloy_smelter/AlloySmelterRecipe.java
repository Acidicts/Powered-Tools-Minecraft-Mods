package net.acidicts.poweredtools.recipe.alloy_smelter;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.acidicts.poweredtools.block.ModBlocks;
import net.acidicts.poweredtools.recipe.ModRecipes;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record AlloySmelterRecipe(class_1856 input1, class_1856 input2, class_1856 input3, class_1799 output, int cookingTime) implements class_1860<AlloySmelterRecipeInput> {
    @Override
    public class_2371<class_1856> method_8117() {
        class_2371<class_1856> list = class_2371.method_10211();
        list.add(this.input1);
        list.add(this.input2);
        list.add(this.input3);

        return list;
    }

    @Override
    public class_1799 method_17447() {
        return new class_1799(ModBlocks.ALLOY_SMELTER);
    }

    public int getCookingTime() {
        return cookingTime;
    }

    @Override
    public boolean matches(AlloySmelterRecipeInput input, class_1937 world) {
        if (world.field_9236) {
            return false;
        }

        boolean[] slotMatched = new boolean[3];
        boolean[] ingredientMatched = new boolean[3];
        class_1856[] ingredients = {input1, input2, input3};

        // Try to match each slot with an unmatched ingredient
        for (int slot = 0; slot < 3; slot++) {
            class_1799 stack = input.method_59984(slot);
            if (stack.method_7960()) {
                continue;
            }

            for (int ing = 0; ing < 3; ing++) {
                if (!ingredientMatched[ing] && ingredients[ing].method_8093(stack)) {
                    slotMatched[slot] = true;
                    ingredientMatched[ing] = true;
                    break;
                }
            }
        }

        // All three ingredients must be matched
        return ingredientMatched[0] && ingredientMatched[1] && ingredientMatched[2];
    }

    @Override
    public class_1799 craft(AlloySmelterRecipeInput input, class_7225.class_7874 lookup) {
        return output.method_7972();
    }

    @Override
    public boolean method_8113(int width, int height) {
        return true;
    }

    @Override
    public class_1799 method_8110(class_7225.class_7874 registriesLookup) {
        return output;
    }

    @Override
    public class_1865<?> method_8119() {
        return ModRecipes.ALLOY_SMELTER_SERIALIZER;
    }

    @Override
    public class_3956<?> method_17716() {
        return ModRecipes.ALLOYING_TYPE;
    }

    public static class Serializer implements class_1865<AlloySmelterRecipe>{

        public static final MapCodec<AlloySmelterRecipe> CODEC = RecordCodecBuilder.mapCodec(inst -> inst.group(
                class_1856.field_46096.fieldOf("input1").forGetter(AlloySmelterRecipe::input1),
                class_1856.field_46096.fieldOf("input2").forGetter(AlloySmelterRecipe::input2),
                class_1856.field_46096.fieldOf("input3").forGetter(AlloySmelterRecipe::input3),
                class_1799.field_24671.fieldOf("output").forGetter(AlloySmelterRecipe::output),
                com.mojang.serialization.Codec.INT.fieldOf("cookingtime").forGetter(AlloySmelterRecipe::cookingTime)
        ).apply(inst, AlloySmelterRecipe::new));

        public static final class_9139<class_9129, AlloySmelterRecipe> STREAM_CODEC =
                class_9139.method_56906(
                        class_1856.field_48355, AlloySmelterRecipe::input1,
                        class_1856.field_48355, AlloySmelterRecipe::input2,
                        class_1856.field_48355, AlloySmelterRecipe::input3,
                        class_1799.field_48349, AlloySmelterRecipe::output,
                        class_9139.method_56437((buf, value) -> buf.method_53002(value), buf -> buf.readInt()), AlloySmelterRecipe::cookingTime,
                        AlloySmelterRecipe::new
                );

        @Override
        public MapCodec<AlloySmelterRecipe> method_53736() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, AlloySmelterRecipe> method_56104() {
            return STREAM_CODEC;
        }
    }
}

