package net.acidicts.poweredtools.recipe.alloy_smelter;

import net.acidicts.poweredtools.block.ModBlocks;
import net.acidicts.poweredtools.recipe.ModRecipes;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1874;
import net.minecraft.class_7709;

public class AlloySmelterRecipeClass extends class_1874 {
    public AlloySmelterRecipeClass(String group, class_7709 category, class_1856 ingredient, class_1799 result, float experience, int cookingTime) {
        super(ModRecipes.RECYCLER_TYPE, group, category, ingredient, result, experience, cookingTime);
    }

    public class_1799 method_17447() {
        return new class_1799(ModBlocks.RECYCLER);
    }

    public class_1865<?> method_8119() {
        return ModRecipes.RECYCLER_SERIALIZER;
    }
}