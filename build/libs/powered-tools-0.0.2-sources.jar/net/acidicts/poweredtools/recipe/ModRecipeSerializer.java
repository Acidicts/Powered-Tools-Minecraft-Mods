package net.acidicts.poweredtools.recipe;

import com.mojang.serialization.MapCodec;
import net.acidicts.poweredtools.recipe.recycler.RecyclerRecipeClass;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_2378;
import net.minecraft.class_3957;
import net.minecraft.class_7923;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.recipe.*;

public interface ModRecipeSerializer<T extends class_1860<?>> {
    class_1865<RecyclerRecipeClass> RECYCLING = register("recycling", new class_3957(RecyclerRecipeClass::new, 72));
    class_1865<RecyclerRecipeClass> ALLOYING = register("recycling", new class_3957(RecyclerRecipeClass::new, 72));

    MapCodec<T> codec();

    class_9139<class_9129, T> packetCodec();

    static <S extends net.minecraft.class_1865<T>, T extends class_1860<?>> S register(String id, S serializer) {
        return (S)(class_2378.method_10226(class_7923.field_41189, id, serializer));
    }
}
