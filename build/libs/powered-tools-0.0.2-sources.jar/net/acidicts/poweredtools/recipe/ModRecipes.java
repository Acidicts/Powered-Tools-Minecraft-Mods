package net.acidicts.poweredtools.recipe;

import net.acidicts.poweredtools.PoweredTools;
import net.acidicts.poweredtools.recipe.alloy_smelter.AlloySmelterRecipe;
import net.acidicts.poweredtools.recipe.recycler.RecyclerRecipe;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1935;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_7923;
import net.minecraft.class_8790;
import java.util.List;

import static net.minecraft.class_2446.*;


public class ModRecipes {
    public static final class_1865<RecyclerRecipe> RECYCLER_SERIALIZER = class_2378.method_10230(
            class_7923.field_41189, class_2960.method_60655(PoweredTools.MOD_ID, "recycling"), new RecyclerRecipe.Serializer()
    );
    public static final class_1865<AlloySmelterRecipe> ALLOY_SMELTER_SERIALIZER = class_2378.method_10230(
            class_7923.field_41189, class_2960.method_60655(PoweredTools.MOD_ID, "alloying"), new AlloySmelterRecipe.Serializer()
    );

    public static class_3956<RecyclerRecipe> RECYCLER_TYPE = class_2378.method_10230(
            class_7923.field_41188, class_2960.method_60655(PoweredTools.MOD_ID, "recycling"), new class_3956<>() {
                @Override
                public String toString() {
                    return "recycling";
                }
            }
    );
    public static class_3956<AlloySmelterRecipe> ALLOYING_TYPE = class_2378.method_10230(
            class_7923.field_41188, class_2960.method_60655(PoweredTools.MOD_ID, "alloying"), new class_3956<>() {
                @Override
                public String toString() {
                    return "alloying";
                }
            }
    );

    public static void registerRecipes() {
        PoweredTools.LOGGER.info("Registering Mod Recipes for " + PoweredTools.MOD_ID);

        class_2378.method_10230(class_7923.field_41189, class_2960.method_60655(PoweredTools.MOD_ID, "recycling"), RECYCLER_SERIALIZER);
        class_2378.method_10230(class_7923.field_41189, class_2960.method_60655(PoweredTools.MOD_ID, "alloying"), ALLOY_SMELTER_SERIALIZER);
    }

    public static void offerRecycling(class_8790 exporter, List<class_1935> inputs, ModRecipeCategory category, class_1935 output, float experience, int cookingTime, String group) {
        for(class_1935 input : inputs) {
            RecyclerRecipe recipe = new RecyclerRecipe(
                    class_1856.method_8091(input),
                    new net.minecraft.class_1799(output.method_8389()),
                    cookingTime
            );
            exporter.method_53819(
                    class_2960.method_60655(PoweredTools.MOD_ID, method_33716(output) + "_from_recycling_" + method_33716(input)),
                    recipe,
                    null
            );
        }

    }

    public static void offerAlloying(class_8790 exporter, class_1935 input1, class_1935 input2, class_1935 input3, ModRecipeCategory category, class_1935 output, float experience, int cookingTime, String group) {
        AlloySmelterRecipe recipe = new AlloySmelterRecipe(
                class_1856.method_8091(input1),
                class_1856.method_8091(input2),
                class_1856.method_8091(input3),
                new net.minecraft.class_1799(output.method_8389()),
                cookingTime
        );
        exporter.method_53819(
                class_2960.method_60655(PoweredTools.MOD_ID, method_33716(output) + "_from_alloying"),
                recipe,
                null
        );

    }
}
