package net.acidicts.poweredtools.item;


import net.acidicts.poweredtools.PoweredTools;
import net.acidicts.poweredtools.item.custom.BatteryItem;
import net.acidicts.poweredtools.item.custom.BrokenBatteryItem;
import net.acidicts.poweredtools.item.custom.ModBatteryMaterials;
import net.acidicts.poweredtools.item.custom.Powered_Pickaxe;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.item.*;

public class ModItems {
    public static final class_1792 POWERED_PICKAXE = registerItem("powered_pickaxe",
            new Powered_Pickaxe(new class_1792.class_1793()));

    public static final class_1792 BATTERY_TIER_0 = registerItem("battery_0",
            new BatteryItem(ModBatteryMaterials.Stone, new class_1792.class_1793()));
    public static final class_1792 BATTERY_TIER_1 = registerItem("battery_1",
            new BatteryItem(ModBatteryMaterials.Iron, new class_1792.class_1793()));
    public static final class_1792 BATTERY_TIER_2 = registerItem("battery_2",
            new BatteryItem(ModBatteryMaterials.Gold, new class_1792.class_1793()));
    public static final class_1792 BATTERY_TIER_3 = registerItem("battery_3",
            new BatteryItem(ModBatteryMaterials.Diamond, new class_1792.class_1793()));
    public static final class_1792 BATTERY_TIER_4 = registerItem("battery_4",
            new BatteryItem(ModBatteryMaterials.Netherite, new class_1792.class_1793()));
    public static final class_1792 BATTERY_TIER_5 = registerItem("battery_5",
            new BatteryItem(ModBatteryMaterials.Diamond_Gold, new class_1792.class_1793()));


    public static final class_1792 BROKEN_BATTERY_TIER_0 = registerItem("broken_battery_0",
            new BrokenBatteryItem(ModBatteryMaterials.Stone, new class_1792.class_1793()));
    public static final class_1792 BROKEN_BATTERY_TIER_1 = registerItem("broken_battery_1",
            new BrokenBatteryItem(ModBatteryMaterials.Iron, new class_1792.class_1793()));
    public static final class_1792 BROKEN_BATTERY_TIER_2 = registerItem("broken_battery_2",
            new BrokenBatteryItem(ModBatteryMaterials.Gold, new class_1792.class_1793()));
    public static final class_1792 BROKEN_BATTERY_TIER_3 = registerItem("broken_battery_3",
            new BrokenBatteryItem(ModBatteryMaterials.Diamond, new class_1792.class_1793()));
    public static final class_1792 BROKEN_BATTERY_TIER_4 = registerItem("broken_battery_4",
            new BrokenBatteryItem(ModBatteryMaterials.Netherite, new class_1792.class_1793()));
    public static final class_1792 BROKEN_BATTERY_TIER_5 = registerItem("broken_battery_5",
            new BrokenBatteryItem(ModBatteryMaterials.Diamond_Gold, new class_1792.class_1793()));

    private static class_1792 registerItem(String name, class_1792 item) {
        class_1792 registeredItem = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(PoweredTools.MOD_ID, name), item);

        String translationKey = "item." + PoweredTools.MOD_ID + "." + name;
        String translatedName = class_2561.method_43471(translationKey).getString();

        if (translatedName.equals(translationKey)) {
            translatedName = formatRegistryName(name);
        }

        PoweredTools.LOGGER.info("Registering {} !", translatedName);
        return registeredItem;
    }

    public static String formatRegistryName(String name) {
        String[] words = name.split("_");
        StringBuilder formatted = new StringBuilder();
        for (String word : words) {
            if (!formatted.isEmpty()) {
                formatted.append(" ");
            }
            formatted.append(Character.toUpperCase(word.charAt(0)))
                    .append(word.substring(1));
        }
        return formatted.toString();
    }

    public static class_1792 getBrokenBatteryByTier(String tier) {
        return switch (tier) {
            case "Iron" -> BROKEN_BATTERY_TIER_1;
            case "Gold" -> BROKEN_BATTERY_TIER_2;
            case "Diamond" -> BROKEN_BATTERY_TIER_3;
            case "Netherite" -> BROKEN_BATTERY_TIER_4;
            case "Diamond_Gold" -> BROKEN_BATTERY_TIER_5;
            default -> BROKEN_BATTERY_TIER_0;
        };
    }

    public static void registerItems() {
        PoweredTools.LOGGER.info("Registering Items for " + PoweredTools.MOD_ID);
    }
}
