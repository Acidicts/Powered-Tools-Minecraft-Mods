package net.acidicts.poweredtools.item;

import net.acidicts.poweredtools.PoweredTools;
import net.acidicts.poweredtools.block.ModBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModItemGroups {
    @SuppressWarnings("unused")
    public static final class_1761 POWERED_TOOLS_GROUP = class_2378.method_10230(class_7923.field_44687,
            class_2960.method_60655(PoweredTools.MOD_ID, "powered_tools_group"),
            FabricItemGroup.builder().method_47321(class_2561.method_43471("itemgroup.poweredtools.powered_tools_group"))
                    .method_47320(() -> new class_1799(ModItems.POWERED_PICKAXE))
                    .method_47317(((displayContext, entries) -> {
                        entries.method_45421(ModItems.POWERED_PICKAXE);

                        entries.method_45421(ModBlocks.CHARGER);
                        entries.method_45421(ModBlocks.RECYCLER);
                        entries.method_45421(ModBlocks.COAL_GENERATOR);
                        entries.method_45421(ModBlocks.ALLOY_SMELTER);

                        entries.method_45421(ModItems.BATTERY_TIER_0);
                        entries.method_45421(ModItems.BATTERY_TIER_1);
                        entries.method_45421(ModItems.BATTERY_TIER_2);
                        entries.method_45421(ModItems.BATTERY_TIER_3);
                        entries.method_45421(ModItems.BATTERY_TIER_4);
                        entries.method_45421(ModItems.BATTERY_TIER_5);

                        entries.method_45421(ModItems.BROKEN_BATTERY_TIER_0);
                        entries.method_45421(ModItems.BROKEN_BATTERY_TIER_1);
                        entries.method_45421(ModItems.BROKEN_BATTERY_TIER_2);
                        entries.method_45421(ModItems.BROKEN_BATTERY_TIER_3);
                        entries.method_45421(ModItems.BROKEN_BATTERY_TIER_4);
                        entries.method_45421(ModItems.BROKEN_BATTERY_TIER_5);
                    }))
                    .method_47324());


    public static void registerItemGroups() {
        PoweredTools.LOGGER.info("Registering Item Groups for " + PoweredTools.MOD_ID);
    }
}
