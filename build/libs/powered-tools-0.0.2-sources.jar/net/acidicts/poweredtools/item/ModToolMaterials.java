package net.acidicts.poweredtools.item;

import com.google.common.base.Suppliers;
import java.util.function.Supplier;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_2248;
import net.minecraft.class_3481;
import net.minecraft.class_6862;

public enum ModToolMaterials implements class_1832 {
    PoweredTool(class_3481.field_49925, Integer.MAX_VALUE, 10.0F, 4.0F, 12, () -> class_1856.method_35226());

    private final class_6862<class_2248> inverseTag;
    private final int itemDurability;
    private final float miningSpeed;
    private final float attackDamage;
    private final int enchantability;
    private final Supplier<class_1856> repairIngredient;

    private ModToolMaterials(
            final class_6862<class_2248> inverseTag,
            final int itemDurability,
            final float miningSpeed,
            final float attackDamage,
            final int enchantability,
            final Supplier<class_1856> repairIngredient
    ) {
        this.inverseTag = inverseTag;
        this.itemDurability = itemDurability;
        this.miningSpeed = miningSpeed;
        this.attackDamage = attackDamage;
        this.enchantability = enchantability;
        this.repairIngredient = Suppliers.memoize(repairIngredient::get);
    }

    @Override
    public int method_8025() {
        return this.itemDurability;
    }

    @Override
    public float method_8027() {
        return this.miningSpeed;
    }

    @Override
    public float method_8028() {
        return this.attackDamage;
    }

    @Override
    public class_6862<class_2248> method_58419() {
        return this.inverseTag;
    }

    @Override
    public int method_8026() {
        return this.enchantability;
    }

    @Override
    public class_1856 method_8023() {
        return this.repairIngredient.get();
    }
}
