package net.acidicts.poweredtools.item.custom;

import net.acidicts.poweredtools.PoweredTools;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import java.util.Map;

public class BrokenBatteryItem extends class_1792 {
    public final BatteryMaterial material;
    public final int max_capacity;
    public final int transfer_rate;
    public final int lifespan;
    public final float decay_rate;
    public final String tier;

    private Map<String, Integer> tier_dict = Map.of(
            "Stone", 0,
            "Iron", 1,
            "Gold", 2,
            "Diamond", 3,
            "Netherite", 4,
            "Diamond_Gold", 5
    );

    public BrokenBatteryItem(BatteryMaterial material, class_1793 settings) {
        super(settings.method_7889(64));

        this.material = material;
        this.max_capacity = material.getCapacity();
        this.transfer_rate = material.getTransferRate();
        this.lifespan = material.getLifespan();
        this.decay_rate = material.getDecayRate();
        this.tier = material.getTier();
    }

    public int getTierInt() {
        return tier_dict.getOrDefault(this.tier, 0);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        if (!world.field_9236) {
            class_1799 stack = user.method_5998(hand);
            PoweredTools.LOGGER.info("This battery is broken and cannot be used. Tier: {} ({}).", this.tier, this.getTierInt());
        }
        return class_1271.method_22427(user.method_5998(hand));
    }
}
