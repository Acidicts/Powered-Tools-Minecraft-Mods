package net.acidicts.poweredtools.item.custom;

import net.acidicts.poweredtools.PoweredTools;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import team.reborn.energy.api.base.SimpleEnergyStorage;

import java.util.List;
import java.util.Map;

public class BatteryItem extends class_1792 {

    private final BatteryMaterial material;

    private final Map<String, Integer> tier_dict = Map.of(
            "Stone", 0,
            "Iron", 1,
            "Gold", 2,
            "Diamond", 3,
            "Netherite", 4,
            "Diamond_Gold", 5
    );

    public BatteryItem(BatteryMaterial material, class_1793 settings) {
        super(settings.method_7889(1).method_57349(class_9334.field_49628, class_9279.field_49302));

        this.material = material;
    }

    @Override
    public class_1799 method_7854() {
        class_1799 stack = super.method_7854();
        initializeBatteryNbt(stack);
        return stack;
    }

    private void initializeBatteryNbt(class_1799 stack) {
        class_2487 nbt = stack.method_57825(class_9334.field_49628, class_9279.field_49302).method_57461();

        if (!nbt.method_10545("tier")) {
            nbt.method_10582("tier", material.getTier());
        }
        if (!nbt.method_10545("cycles")) {
            nbt.method_10569("cycles", 0);
        }
        if (!nbt.method_10545("currentCharge")) {
            nbt.method_10544("currentCharge", 0L);
        }

        stack.method_57379(class_9334.field_49628, class_9279.method_57456(nbt));
    }

    private Map<String, Number> getBatteryTierProperties(String tier) {
        return switch (tier) {
            case "Stone" -> Map.of(
                    "capacity", 100,
                    "transferRate", 25,
                    "lifespan", 5,
                    "tierLevel", 0,
                    "decayRate", 0.04f
            );
            case "Iron" -> Map.of(
                    "capacity", 500,
                    "transferRate", 50,
                    "lifespan", 25,
                    "tierLevel", 1,
                    "decayRate", 0.02f
            );
            case "Gold" -> Map.of(
                    "capacity", 1000,
                    "transferRate", 100,
                    "lifespan", 50,
                    "tierLevel", 2,
                    "decayRate", 0.015f
            );
            case "Diamond" -> Map.of(
                    "capacity", 5000,
                    "transferRate", 250,
                    "lifespan", 200,
                    "tierLevel", 3,
                    "decayRate", 0.01f
            );
            case "Netherite" -> Map.of(
                    "capacity", 10000,
                    "transferRate", 500,
                    "lifespan", 500,
                    "tierLevel", 4,
                    "decayRate", 0.005f
            );
            case "Diamond_Gold" -> Map.of(
                    "capacity", 20000,
                    "transferRate", 1000,
                    "lifespan", 1000,
                    "tierLevel", 5,
                    "decayRate", 0.002f
            );
            default -> Map.of(
                    "capacity", 0,
                    "transferRate", 0,
                    "lifespan", 0,
                    "tierLevel", 0,
                    "decayRate", 0f
            );
        };
    }

    public boolean isBroken(class_1799 stack) {
        return getCycles(stack) >= getBatteryLifespan(stack);
    }

    public int getBatteryLifespan(class_1799 stack) {
        return (int) getBatteryTierProperties((String) getTier(stack, "string")).get("lifespan");
    }

    public Object getTier(class_1799 stack, String DataType) {
        switch (DataType) {
            case "int" -> {
                String str = readNbt(stack, "tier", "string").toString();
                if (str == null || str.isEmpty()) {
                    str = material.getTier();
                }
                return tier_dict.getOrDefault(str, 0);
            }
            case "string" -> {
                Object result = readNbt(stack, "tier", "string");
                if (result == null || result.toString().isEmpty()) {
                    return material.getTier();
                }
                return result;
            }
            default -> {
                return null;
            }
        }
    }

    public Object readNbt(class_1799 stack, String key, String dataType) {
        class_2487 nbt = stack.method_57825(class_9334.field_49628, class_9279.field_49302).method_57461();

        switch (dataType) {
            case "int" -> {
                return nbt.method_10550(key);
            }
            case "float" -> {
                return nbt.method_10583(key);
            }
            case "string" -> {
                return nbt.method_10558(key);
            }
            case "long" -> {
                return nbt.method_10537(key);
            }
            case "double" -> {
                return nbt.method_10574(key);
            }
            case "boolean" -> {
                return nbt.method_10577(key);
            }
            default -> {
                return null;
            }
        }
    }

    public void writeNbt(class_1799 stack, String key, String dataType, Object value) {
        class_2487 nbt = stack.method_57825(class_9334.field_49628, class_9279.field_49302).method_57461();

        switch (dataType) {
            case "int" -> nbt.method_10569(key, ((Number) value).intValue());
            case "float" -> nbt.method_10548(key, ((Number) value).floatValue());
            case "string" -> nbt.method_10582(key, (String) value);
            case "long" -> nbt.method_10544(key, ((Number) value).longValue());
            case "double" -> nbt.method_10549(key, ((Number) value).doubleValue());
            case "boolean" -> nbt.method_10556(key, (Boolean) value);
        }

        stack.method_57379(class_9334.field_49628, class_9279.method_57456(nbt));
    }

    @Override
    public void method_7888(class_1799 stack, class_1937 world, class_1297 entity, int slot, boolean selected) {
        class_2487 nbt = stack.method_57825(class_9334.field_49628, class_9279.field_49302).method_57461();
        if (!nbt.method_10545("tier") || !nbt.method_10545("cycles")) {
            initializeBatteryNbt(stack);
        }
        correctCharge(stack);

        super.method_7888(stack, world, entity, slot, selected);
    }

    public int getTransferRate(class_1799 stack) {
        return (int) getBatteryTierProperties((String) getTier(stack, "string")).get("transferRate");
    }

    private void setCycles(class_1799 stack, int i) {
        writeNbt(stack, "cycles", "int", i);
    }

    public int recharge(class_1799 stack, int amount) {
        int accepted = getMaxCapacity(stack) - getCurrentCharge(stack);
        if (accepted >= amount) {
            accepted = amount;
        }
        int denied = Math.max(amount - accepted, 0);
        PoweredTools.LOGGER.info(String.valueOf(accepted));

        SimpleEnergyStorage energyStorage = new SimpleEnergyStorage(getMaxCapacity(stack), getTransferRate(stack), getTransferRate(stack));
        energyStorage.amount = getCurrentCharge(stack);

        try (Transaction transaction = Transaction.openOuter()) {
            energyStorage.insert(accepted, transaction);
            transaction.commit();
        }
        setCurrentCharge(stack, Math.toIntExact(energyStorage.getAmount()));

        if (energyStorage.amount == getMaxCapacity(stack)) {
            setCycles(stack, getCycles(stack) + 1);
        }

        return denied;
    }

    public int discharge(class_1799 stack, int amount) {
        int available = getCurrentCharge(stack);
        if (available >= amount) {
            available = amount;
        }
        int denied = Math.max(amount - available, 0);

        SimpleEnergyStorage energyStorage = new SimpleEnergyStorage(getMaxCapacity(stack), getTransferRate(stack), getTransferRate(stack));
        energyStorage.amount = getCurrentCharge(stack);

        try (Transaction transaction = Transaction.openOuter()) {
            energyStorage.extract(available, transaction);
            transaction.commit();
        }

        setCurrentCharge(stack, Math.toIntExact(energyStorage.getAmount()));

        if (energyStorage.amount >= getMaxCapacity(stack)) {
            setCycles(stack, getCycles(stack) + 1);
        }

        return denied;
    }

    private void correctCharge(class_1799 stack) {
        int maxCapacity = getMaxCapacity(stack);
        if (getCurrentCharge(stack) > maxCapacity) {
            setCurrentCharge(stack, maxCapacity);
        }
    }

    public int getCycles(class_1799 stack) {
        return (int) readNbt(stack, "cycles", "int");
    }

    public int getCurrentCharge(class_1799 stack) {
        return Math.toIntExact((long) readNbt(stack, "currentCharge", "long"));
    }

    public void setCurrentCharge(class_1799 stack, int charge) {
        int modded_charge = Math.max(0, Math.min(charge, getMaxCapacity(stack)));
        writeNbt(stack, "currentCharge", "long", modded_charge);
    }

    public int getMaxCapacity(class_1799 stack) {
        int max_cap = (int) getBatteryTierProperties((String) getTier(stack, "string")).get("capacity");
        float degradation = (float) getBatteryTierProperties((String) getTier(stack, "string")).get("decayRate");

        return (int) (max_cap * (1.0f - (degradation * getCycles(stack))));
    }

    public float getDecayRate(class_1799 stack) {
        return (float) getBatteryTierProperties((String) getTier(stack, "string")).get("decayRate");
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltip, net.minecraft.class_1836 type) {
        Map<String, Number> properties = getBatteryTierProperties((String) getTier(stack, "string"));

        int currentCharge = getCurrentCharge(stack);
        int maxCapacity = getMaxCapacity(stack);
        int cycles = getCycles(stack);
        int lifespan = getBatteryLifespan(stack);

        int remainingCycles = lifespan - cycles;

        tooltip.add(class_2561.method_43470("Charge: " + currentCharge + " / " + maxCapacity).method_27692(class_124.field_1060));
        tooltip.add(class_2561.method_43470("Transfer Rate: " + properties.get("transferRate") + " per tick").method_27692(class_124.field_1075));
        tooltip.add(class_2561.method_43470("Remaining Cycles: " + remainingCycles).method_27692(
            remainingCycles > lifespan * 0.5 ? class_124.field_1060 :
            remainingCycles > lifespan * 0.25 ? class_124.field_1054 : class_124.field_1061
        ));
        tooltip.add(class_2561.method_43470("Tier: " + (String) getTier(stack, "string")).method_27692(class_124.field_1065));
    }

    @Override
    public boolean method_31567(class_1799 stack) {
        return true;
    }

    @Override
    public int method_31569(class_1799 stack) {
        int currentCharge = getCurrentCharge(stack);
        int maxCapacity = getMaxCapacity(stack);
        if (maxCapacity == 0) return 0;
        return Math.round(13.0F * currentCharge / maxCapacity);
    }

    @Override
    public int method_31571(class_1799 stack) {
        int currentCharge = getCurrentCharge(stack);
        int maxCapacity = getMaxCapacity(stack);
        if (maxCapacity == 0) return 0xFF0000;

        float ratio = (float) currentCharge / maxCapacity;

        if (ratio > 0.5F) {
            return 0x00FF00;
        } else if (ratio > 0.25F) {
            return 0xFFFF00;
        } else {
            return 0xFF0000;
        }
    }
}
