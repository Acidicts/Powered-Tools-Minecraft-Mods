package net.acidicts.poweredtools.item.custom;

import net.acidicts.poweredtools.item.ModToolMaterials;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import java.util.List;

public class Powered_Pickaxe extends class_1810 {

    private static final int ENERGY_PER_USE = 10;

    public Powered_Pickaxe(class_1793 settings) {
        super(ModToolMaterials.PoweredTool, settings.method_7889(1));
    }

    private void initializeBattery(class_1799 stack) {
        if (!hasBattery(stack)) {
            resetToDefaultBattery(stack);
        }
    }

    private void resetToDefaultBattery(class_1799 stack) {
        class_2487 nbt = new class_2487();
        nbt.method_10582("battery_tier", "Stone");
        nbt.method_10569("battery_capacity", 100);
        nbt.method_10569("battery_transfer_rate", 25);
        nbt.method_10569("battery_lifespan", 5);
        nbt.method_10548("battery_decay_rate", 0.04f);
        nbt.method_10569("battery_cycles", 0);
        nbt.method_10569("battery_charge", 100);
        nbt.method_10556("battery_installed", true);
        stack.method_57379(class_9334.field_49628, class_9279.method_57456(nbt));
    }

    private boolean hasBattery(class_1799 stack) {
        class_9279 nbtComponent = stack.method_57824(class_9334.field_49628);
        if (nbtComponent == null) {
            return false;
        }
        return nbtComponent.method_57461().method_10545("battery_tier");
    }

    private class_2487 getBatteryData(class_1799 stack) {
        initializeBattery(stack);
        class_9279 nbtComponent = stack.method_57825(class_9334.field_49628, class_9279.field_49302);
        return nbtComponent.method_57461();
    }

    private void setBatteryData(class_1799 stack, class_2487 nbt) {
        stack.method_57379(class_9334.field_49628, class_9279.method_57456(nbt));
    }

    public int getEnergy(class_1799 stack) {
        class_2487 nbt = getBatteryData(stack);
        if (!nbt.method_10577("battery_installed")) {
            return 0;
        }
        return nbt.method_10550("battery_charge");
    }

    public void setEnergy(class_1799 stack, int energy) {
        class_2487 nbt = getBatteryData(stack);
        if (!nbt.method_10577("battery_installed")) {
            return;
        }
        int maxCapacity = getMaxCapacity(stack);
        energy = Math.max(0, Math.min(energy, maxCapacity));
        nbt.method_10569("battery_charge", energy);
        setBatteryData(stack, nbt);
    }

    public int getMaxCapacity(class_1799 stack) {
        class_2487 nbt = getBatteryData(stack);
        if (!nbt.method_10577("battery_installed")) {
            return 0;
        }
        int baseCapacity = nbt.method_10550("battery_capacity");
        int cycles = nbt.method_10550("battery_cycles");
        float decayRate = nbt.method_10583("battery_decay_rate");
        return (int) (baseCapacity * (1.0f - (decayRate * cycles)));
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 pickaxeStack = user.method_5998(hand);
        class_1799 offhandStack = user.method_6079();



        if (user.method_5715()) {
            if (!world.field_9236) {
                class_2487 nbt = getBatteryData(pickaxeStack);
                if (nbt.method_10577("battery_installed")) {
                    class_1799 extractedBattery = extractBatteryAsItem(pickaxeStack);

                    class_2487 pickaxeNbt = new class_2487();
                    pickaxeNbt.method_10556("battery_installed", false);
                    pickaxeNbt.method_10582("battery_tier", "");
                    pickaxeNbt.method_10569("battery_capacity", 0);
                    pickaxeNbt.method_10569("battery_transfer_rate", 0);
                    pickaxeNbt.method_10569("battery_lifespan", 0);
                    pickaxeNbt.method_10548("battery_decay_rate", 0f);
                    pickaxeNbt.method_10569("battery_cycles", 0);
                    pickaxeNbt.method_10569("battery_charge", 0);
                    setBatteryData(pickaxeStack, pickaxeNbt);

                    if (!user.method_31548().method_7394(extractedBattery)) {
                        user.method_7328(extractedBattery, false);
                    }

                    user.method_7353(class_2561.method_43470("Battery removed!").method_27692(class_124.field_1054), true);
                } else {
                    user.method_7353(class_2561.method_43470("No battery to remove!").method_27692(class_124.field_1061), true);
                }
            }
            return class_1271.method_29237(pickaxeStack, world.method_8608());
        }

        if (offhandStack.method_7909() instanceof BatteryItem batteryItem) {
            if (!world.field_9236) {
                class_2487 nbt = getBatteryData(pickaxeStack);
                if (nbt.method_10577("battery_installed")) {
                    class_1799 oldBatteryStack = extractBatteryAsItem(pickaxeStack);

                    installBattery(pickaxeStack, offhandStack, batteryItem);

                    offhandStack.method_7934(1);

                    if ((!user.method_31548().method_7394(oldBatteryStack))) {
                        user.method_7328(oldBatteryStack, false);
                    }
                } else {
                    installBattery(pickaxeStack, offhandStack, batteryItem);

                    offhandStack.method_7934(1);
                }

                user.method_7353(class_2561.method_43470("Battery swapped!").method_27692(class_124.field_1060), true);
            }
            return class_1271.method_29237(pickaxeStack, world.method_8608());
        } else if (offhandStack.method_7909() instanceof BrokenBatteryItem) {
            user.method_7353(class_2561.method_30163("Your battery is broken and cannot be used."), true);
        }

        return class_1271.method_22430(pickaxeStack);
    }

    private class_1799 extractBatteryAsItem(class_1799 pickaxeStack) {
        class_2487 pickaxeNbt = getBatteryData(pickaxeStack);

        String tier = pickaxeNbt.method_10558("battery_tier");

        class_1792 batteryItemType = getBatteryItemByTier(tier);
        class_1799 batteryStack = new class_1799(batteryItemType);

        class_2487 batteryNbt = new class_2487();
        batteryNbt.method_10569("cycles", pickaxeNbt.method_10550("battery_cycles"));
        batteryNbt.method_10544("currentCharge", pickaxeNbt.method_10550("battery_charge"));
        batteryStack.method_57379(class_9334.field_49628, class_9279.method_57456(batteryNbt));


        return batteryStack;
    }
    private class_1792 getBatteryItemByTier(String tier) {
        return switch (tier.toLowerCase()) {
            case "iron" -> net.acidicts.poweredtools.item.ModItems.BATTERY_TIER_1;
            case "gold" -> net.acidicts.poweredtools.item.ModItems.BATTERY_TIER_2;
            case "diamond" -> net.acidicts.poweredtools.item.ModItems.BATTERY_TIER_3;
            case "netherite" -> net.acidicts.poweredtools.item.ModItems.BATTERY_TIER_4;
            case "diamond_gold" -> net.acidicts.poweredtools.item.ModItems.BATTERY_TIER_5;
            default -> net.acidicts.poweredtools.item.ModItems.BATTERY_TIER_0;
        };
    }

    private void installBattery(class_1799 pickaxeStack, class_1799 batteryStack, BatteryItem batteryItem) {
        class_2487 pickaxeNbt = new class_2487();

        pickaxeNbt.method_10582("battery_tier", (String) batteryItem.getTier(batteryStack, "string"));
        pickaxeNbt.method_10569("battery_capacity", batteryItem.getMaxCapacity(batteryStack));
        pickaxeNbt.method_10569("battery_transfer_rate", batteryItem.getTransferRate(batteryStack));
        pickaxeNbt.method_10569("battery_lifespan", batteryItem.getBatteryLifespan(batteryStack));
        pickaxeNbt.method_10548("battery_decay_rate", batteryItem.getDecayRate(batteryStack));
        pickaxeNbt.method_10556("battery_installed", true);

        int cycles = batteryItem.getCycles(batteryStack);
        int charge = batteryItem.getCurrentCharge(batteryStack);

        pickaxeNbt.method_10569("battery_cycles", cycles);
        pickaxeNbt.method_10569("battery_charge", charge);

        setBatteryData(pickaxeStack, pickaxeNbt);
    }


    @Override
    public boolean method_31567(class_1799 stack) {
        return true;
    }

    @Override
    public int method_31569(class_1799 stack) {
        class_2487 nbt = getBatteryData(stack);
        if (nbt.method_10577("battery_installed")) {
            int energy = getEnergy(stack);
            int maxCapacity = getMaxCapacity(stack);
            if (maxCapacity == 0) return 0;
            return Math.round(13.0F * energy / maxCapacity);
        }
        return (int) 13.0F;
    }

    @Override
    public int method_31571(class_1799 stack) {
        class_2487 nbt = getBatteryData(stack);
        if (nbt.method_10577("battery_installed")) {
            int energy = getEnergy(stack);
            int maxCapacity = getMaxCapacity(stack);
            if (maxCapacity == 0) return 0xFF0000;

            float ratio = (float) energy / maxCapacity;

            if (ratio > 0.5F) {
                return 0x00FFFF;
            } else if (ratio > 0.25F) {
                return 0xFFFF00;
            } else {
                return 0xFF0000;
            }
        }
        return 0xFF0000;
    }

    @Override
    public boolean method_7879(class_1799 stack, class_1937 world, class_2680 state, class_2338 pos, class_1309 miner) {
        if (!world.field_9236 && state.method_26214(world, pos) != 0.0F) {
            int currentEnergy = getEnergy(stack);
            if (currentEnergy >= ENERGY_PER_USE) {
                setEnergy(stack, currentEnergy - ENERGY_PER_USE);
            }
        }
        return false;
    }

    @Override
    public float method_58404(class_1799 stack, class_2680 state) {
        if (getEnergy(stack) < ENERGY_PER_USE) {
            return 0.0F;
        }
        return super.method_58404(stack, state);
    }

    @Override
    public boolean method_7885(class_2680 state, class_1937 world, class_2338 pos, class_1657 miner) {
        class_1799 stack = miner.method_6047();
        return getEnergy(stack) >= ENERGY_PER_USE && super.method_7885(state, world, pos, miner);
    }

    @SuppressWarnings("unused")
    public void addEnergy(class_1799 stack, int amount) {
        int currentEnergy = getEnergy(stack);
        setEnergy(stack, currentEnergy + amount);
    }

    public int cyclesLeft(class_1799 stack) {
        class_2487 nbt = getBatteryData(stack);
        int cycles = nbt.method_10550("battery_cycles");
        int lifespan = nbt.method_10550("battery_lifespan");
        return lifespan - cycles;
    }

    public void setCycles(class_1799 stack, int cycles){
        class_2487 nbt = getBatteryData(stack);
        nbt.method_10569("battery_cycles", cycles);
        setBatteryData(stack, nbt);
    }

    public int getCycles(class_1799 stack){
        class_2487 nbt = getBatteryData(stack);
        return nbt.method_10550("battery_cycles");
    }

    private int getCurrentCharge(class_1799 stack){
        class_2487 nbt = getBatteryData(stack);
        return nbt.method_10550("battery_charge");
    }

    public void setCurrentCharge(class_1799 stack, int charge){
        class_2487 nbt = getBatteryData(stack);
        nbt.method_10569("battery_charge", charge);
        setBatteryData(stack, nbt);
    }

    @SuppressWarnings("unused")
    public void recharge(class_1799 stack, int amount) {
        int currentCharge = getCurrentCharge(stack);
        int maxCapacity = getMaxCapacity(stack);
        int newCharge = Math.min(maxCapacity, currentCharge + amount);

        if (cyclesLeft(stack) > 0) {
            int currentEnergy = getEnergy(stack);
            setEnergy(stack, currentEnergy + amount);

            setCycles(stack, getCycles(stack)+ 1);
            int newMaxCapacity = getMaxCapacity(stack);
            if (newCharge > newMaxCapacity) {
                setCurrentCharge(stack, newMaxCapacity);
            }
        }
    }

    @Override
    public void method_7851(class_1799 stack, class_1792.class_9635 context, List<class_2561> tooltip, class_1836 type) {
        super.method_7851(stack, context, tooltip, type);
        class_2487 nbt = getBatteryData(stack);

        if (nbt.method_10577("battery_installed")) {
            int energy = getEnergy(stack);
            int maxCapacity = getMaxCapacity(stack);
            String tier = nbt.method_10558("battery_tier");
            int cycles = nbt.method_10550("battery_cycles");
            int lifespan = nbt.method_10550("battery_lifespan");
            int remainingCycles = lifespan - cycles;

            tooltip.add(class_2561.method_43470("Energy: " + energy + " / " + maxCapacity)
                    .method_27692(energy > maxCapacity * 0.5 ? class_124.field_1060 :
                            energy > maxCapacity * 0.25 ? class_124.field_1054 : class_124.field_1061));
            tooltip.add(class_2561.method_43470("Battery Tier: " + tier).method_27692(class_124.field_1065));
            tooltip.add(class_2561.method_43470("Remaining Battery Cycles: " + remainingCycles).method_27692(
                    remainingCycles > lifespan * 0.5 ? class_124.field_1060 :
                            remainingCycles > lifespan * 0.25 ? class_124.field_1054 : class_124.field_1061
            ));
            tooltip.add(class_2561.method_43470("Hold battery in offhand + right-click to swap").method_27692(class_124.field_1080).method_27692(class_124.field_1056));
            tooltip.add(class_2561.method_43470("Sneak + right-click to remove battery").method_27692(class_124.field_1080).method_27692(class_124.field_1056));
        } else {
            tooltip.add(class_2561.method_43470("No battery installed").method_27692(class_124.field_1061));
            tooltip.add(class_2561.method_43470("Hold battery in offhand + right-click to install").method_27692(class_124.field_1080).method_27692(class_124.field_1056));
        }
    }
}
