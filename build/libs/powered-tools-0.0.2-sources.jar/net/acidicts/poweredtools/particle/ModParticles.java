package net.acidicts.poweredtools.particle;

import net.acidicts.poweredtools.PoweredTools;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModParticles {
    public static final class_2400 ELECTRIC_SPARK = register("electric_spark", FabricParticleTypes.simple());

    public static void registerParticles() {
        PoweredTools.LOGGER.info("Registering Mod Particles for " + PoweredTools.MOD_ID);
    }

    private static class_2400 register(String name, class_2400 particleType) {
        return class_2378.method_10230(class_7923.field_41180, class_2960.method_60655(PoweredTools.MOD_ID, name), particleType);
    }
}
