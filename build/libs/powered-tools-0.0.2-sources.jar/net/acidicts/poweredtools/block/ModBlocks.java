package net.acidicts.poweredtools.block;

import net.acidicts.poweredtools.PoweredTools;
import net.acidicts.poweredtools.block.custom.AlloySmelter;
import net.acidicts.poweredtools.block.custom.Charger;
import net.acidicts.poweredtools.block.custom.CoalGenerator;
import net.acidicts.poweredtools.block.custom.Recycler;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

import static net.acidicts.poweredtools.item.ModItems.formatRegistryName;


public class ModBlocks {

    public static final class_2248 CHARGER = registerBlock("charger",
            new Charger(class_4970.class_2251.method_9637().method_22488().method_29292().method_9632(2f).method_36558(12f)));
    public static final class_2248 OPEN_CHARGER = registerBlock("open_charger",
            new class_2248(class_4970.class_2251.method_9637().method_22488().method_29292().method_9632(2f).method_36558(12f)));

    public static final class_2248 RECYCLER = registerBlock("recycler",
            new Recycler(class_4970.class_2251.method_9637().method_22488().method_29292().method_9632(2f).method_36558(12f)));

    public static final class_2248 ALLOY_SMELTER = registerBlock("alloy_smelter",
            new AlloySmelter(class_4970.class_2251.method_9637().method_22488().method_29292().method_9632(2f).method_36558(12f)));

    public static final class_2248 COAL_GENERATOR = registerBlock("coal_generator",
            new CoalGenerator(class_4970.class_2251.method_9637().method_22488().method_29292().method_9632(2f).method_36558(12f)));


    private static class_2248 registerBlock(String name, class_2248 block) {
        registerBlockItem(name, block);
        class_2248 registeredBlock = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(PoweredTools.MOD_ID, name), block);

        String translationKey = "block." + PoweredTools.MOD_ID + "." + name;
        String translatedName = net.minecraft.class_2561.method_43471(translationKey).getString();

        if (translatedName.equals(translationKey)) {
            translatedName = formatRegistryName(name);
        }

        PoweredTools.LOGGER.info("Registering {} !", translatedName);
        return registeredBlock;
    }

    private static void registerBlockItem(String name, class_2248 block) {
        if (name.equals("open_charger")) {
            return;
        }
        class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(PoweredTools.MOD_ID, name), new class_1747(block, new class_1792.class_1793()));
    }

    public static void registerBlocks() {
        PoweredTools.LOGGER.info("Registering Blocks for {}", PoweredTools.MOD_ID);
    }
}
