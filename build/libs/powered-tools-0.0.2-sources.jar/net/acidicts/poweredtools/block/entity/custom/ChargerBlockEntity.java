package net.acidicts.poweredtools.block.entity.custom;

import net.acidicts.poweredtools.PoweredTools;
import net.acidicts.poweredtools.block.entity.ModBlockEntities;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import software.bernie.geckolib.animatable.GeoBlockEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.*;
import software.bernie.geckolib.util.GeckoLibUtil;

public class ChargerBlockEntity extends class_2586 implements GeoBlockEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private boolean hasOpened = false;
    private boolean animationSet = false;
    private int tickCounter = 0;
    private static final int ANIMATION_DURATION_TICKS = 40; // Approximately 2 seconds (20 ticks/second)

    public ChargerBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    public static ChargerBlockEntity createFromNbt(class_2338 pos, class_2680 state, class_2487 nbt) {
        ChargerBlockEntity entity = new ChargerBlockEntity(pos, state);
        entity.method_11014(nbt, null);
        return entity;
    }

    public ChargerBlockEntity(class_2338 pos, class_2680 state) {
        this(ModBlockEntities.CHARGER_BLOCK_ENTITY, pos, state);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        PoweredTools.LOGGER.info("registerControllers called - hasOpened: {}, animationSet: {}", hasOpened, animationSet);
        controllers.add(new AnimationController<>(this, "controller", 0, this::predicate));
    }

    public void tick() {
        if (field_11863 == null || field_11863.field_9236) return;

        // Server-side logic to mark as opened when space is available and animation completes
        if (!hasOpened && hasSpaceToOpen()) {
            tickCounter++;
            if (tickCounter >= ANIMATION_DURATION_TICKS) {
                PoweredTools.LOGGER.info("Charger animation should be complete on server side - setting hasOpened to true");
                setHasOpened(true);
            }
        } else if (!hasSpaceToOpen()) {
            // Reset counter if space becomes unavailable
            tickCounter = 0;
        }
    }

    public boolean hasSpaceToOpen() {
        if (field_11863 == null) return false;

        for (class_2350 direction : class_2350.class_2353.field_11062) {
            class_2338 adjacentPos = field_11867.method_10093(direction);
            class_2680 adjacentState = field_11863.method_8320(adjacentPos);

            if (!adjacentState.method_26215()) {
                return false;
            }
        }

        class_2338 abovePos = field_11867.method_10084();
        class_2680 aboveState = field_11863.method_8320(abovePos);

        if (!aboveState.method_26215()) {
            return false;
        }

        return true;
    }

    private PlayState predicate(AnimationState<ChargerBlockEntity> state) {
        if (hasOpened()) {
            state.getController().setAnimation(RawAnimation.begin().then("Opened", Animation.LoopType.PLAY_ONCE));
            return PlayState.CONTINUE;

        } else {
            if (hasSpaceToOpen()) {
                if (!state.getController().hasAnimationFinished()) {
                    state.getController().setAnimation(RawAnimation.begin().then("Open", Animation.LoopType.HOLD_ON_LAST_FRAME));
                    return PlayState.CONTINUE;
                } else {
                    if (!hasOpened()){
                        setHasOpened(true);
                    }
                    return PlayState.STOP;
                }
            } else {
                state.getController().forceAnimationReset();
                state.getController().stop();
                return PlayState.STOP;
            }
        }
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }

    public boolean hasOpened() {
        return hasOpened;
    }

    public void setHasOpened(boolean hasOpened) {
        PoweredTools.LOGGER.info("setHasOpened called with value: {}", hasOpened);
        this.hasOpened = hasOpened;
        method_5431(); // Mark dirty to ensure NBT is saved to disk
        if (field_11863 != null) {
            field_11863.method_8413(field_11867, method_11010(), method_11010(), 3); // Sync to client
        }
    }

    public class_2487 getNbtData() {
        class_2487 nbt = new class_2487();
        if (field_11863 != null) {
            method_11007(nbt, field_11863.method_30349());
        } else {
            method_11007(nbt, null);
        }
        return nbt;
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registryLookup) {
        super.method_11007(nbt, registryLookup);
        nbt.method_10556("HasOpened", hasOpened);
        PoweredTools.LOGGER.info("writeNbt called - Saving hasOpened as: {}", hasOpened);
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registryLookup) {
        super.method_11014(nbt, registryLookup);
        hasOpened = nbt.method_10577("HasOpened");
        PoweredTools.LOGGER.info("readNbt called - hasOpened loaded as: {}", hasOpened);
        // If it was previously opened, mark animation as already set to prevent restart
        if (hasOpened) {
            animationSet = true;
            PoweredTools.LOGGER.info("readNbt: Setting animationSet to true because hasOpened=true");
        }
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        // This method is called to sync data to the client when the chunk loads
        class_2487 nbt = super.method_16887(registryLookup);
        nbt.method_10556("HasOpened", hasOpened);
        PoweredTools.LOGGER.info("toInitialChunkDataNbt called - Syncing hasOpened: {} to client", hasOpened);
        return nbt;
    }

    @Override
    public net.minecraft.class_2622 method_38235() {
        // This method is called when the block entity state changes and needs to be synced
        return net.minecraft.class_2622.method_38585(this);
    }
}

