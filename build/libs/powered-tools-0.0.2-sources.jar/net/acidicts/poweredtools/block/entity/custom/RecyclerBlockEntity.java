package net.acidicts.poweredtools.block.entity.custom;

import net.acidicts.poweredtools.block.custom.Recycler;
import net.acidicts.poweredtools.block.entity.ImplementedInventory;
import net.acidicts.poweredtools.block.entity.ModBlockEntities;
import net.acidicts.poweredtools.recipe.ModRecipes;
import net.acidicts.poweredtools.recipe.recycler.RecyclerRecipe;
import net.acidicts.poweredtools.recipe.recycler.RecyclerRecipeInput;
import net.acidicts.poweredtools.screen.custom.recycler.RecyclerScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1262;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3913;
import net.minecraft.class_7225;
import net.minecraft.class_8786;
import org.jetbrains.annotations.Nullable;
import team.reborn.energy.api.base.SimpleEnergyStorage;

import java.util.Optional;

public class RecyclerBlockEntity extends class_2586 implements ExtendedScreenHandlerFactory<class_2338>, ImplementedInventory {
    private final class_2371<class_1799> inventory = class_2371.method_10213(4, class_1799.field_8037);

    private static final int BATTERY_MATERIAL_SLOT = 0;
    private static final int INPUT_SLOT = 1;
    private static final int OUTPUT_SLOT = 2;
    private static final int Energy_ITEM_SLOT = 3;

    protected final class_3913 propertyDelegate;
    private int progress = 0;
    private int maxProgress = 72;
    private final int DEFAULT_MAX_PROGRESS = 72;

    private static final int ENERGY_CRAFTING_AMOUNT = 50;
    private static final int ENERGY_TRANSFER_AMOUNT = 320;

    public final SimpleEnergyStorage energyStorage = new SimpleEnergyStorage(64000, ENERGY_TRANSFER_AMOUNT, ENERGY_TRANSFER_AMOUNT) {
        @Override
        protected void onFinalCommit() {
            method_5431();
            method_10997().method_8413(field_11867, method_11010(), method_11010(), 3);
        }
    };

    public RecyclerBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.RECYCLER_BLOCK_ENTITY, pos, state);
        this.propertyDelegate = new class_3913() {
            @Override
            public int method_17390(int index) {
                return switch (index) {
                    case 0 -> RecyclerBlockEntity.this.progress;
                    case 1 -> RecyclerBlockEntity.this.maxProgress;
                    default -> 0;
                };
            }

            @Override
            public void method_17391(int index, int value) {
                switch (index) {
                    case 0: RecyclerBlockEntity.this.progress = value;
                    case 1: RecyclerBlockEntity.this.maxProgress = value;
                }
            }

            @Override
            public int method_17389() {
                return 2;
            }
        };
    }

    @Override
    public boolean method_5492(int slot, class_1799 stack, @Nullable class_2350 side) {
        assert this.method_10997() != null;
        class_2350 localDir = this.method_10997().method_8320(field_11867).method_11654(Recycler.FACING);

        if (side == null) {
            return false;
        }

        if (side == class_2350.field_11033) {
            return false;
        }

        if (side == class_2350.field_11036) {
            return slot == INPUT_SLOT;
        }

        return switch (localDir) {
            case field_11034 ->
                    side.method_10170() == class_2350.field_11043 && slot == INPUT_SLOT ||
                            side.method_10170() == class_2350.field_11039 && slot == INPUT_SLOT;
            case field_11035 ->
                    side == class_2350.field_11043 && slot == INPUT_SLOT ||
                            side == class_2350.field_11039 && slot == INPUT_SLOT;
            case field_11039 ->
                    side.method_10160() == class_2350.field_11043 && slot == INPUT_SLOT ||
                            side.method_10160() == class_2350.field_11039 && slot == INPUT_SLOT;
            default -> // North
                    side.method_10153() == class_2350.field_11043 && slot == INPUT_SLOT ||
                            side.method_10153() == class_2350.field_11039 && slot == INPUT_SLOT;
        };
    }

    @Override
    public boolean method_5493(int slot, class_1799 stack, class_2350 side) {
        assert this.method_10997() != null;
        class_2350 localDir = this.method_10997().method_8320(field_11867).method_11654(Recycler.FACING);

        if (side == class_2350.field_11036) {
            return false;
        }

        if (side == class_2350.field_11033) {
            return slot == OUTPUT_SLOT;
        }

        return switch (localDir) {
            case field_11034 ->
                    side.method_10170() == class_2350.field_11035 && slot == OUTPUT_SLOT ||
                            side.method_10170() == class_2350.field_11034 && slot == OUTPUT_SLOT;
            case field_11035 ->
                    side == class_2350.field_11035 && slot == OUTPUT_SLOT ||
                            side == class_2350.field_11034 && slot == OUTPUT_SLOT;
            case field_11039 ->
                    side.method_10160() == class_2350.field_11035 && slot == OUTPUT_SLOT ||
                            side.method_10160() == class_2350.field_11034 && slot == OUTPUT_SLOT;
            default -> // North
                    side.method_10153() == class_2350.field_11035 && slot == OUTPUT_SLOT ||
                            side.method_10153() == class_2350.field_11034 && slot == OUTPUT_SLOT;
        };
    }

    @Override
    public class_2371<class_1799> getItems() {
        return inventory;
    }

    @Override
    public class_2338 getScreenOpeningData(class_3222 player) {
        return this.field_11867;
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471("gui.poweredtools.recycler");
    }

    @Override
    public @Nullable class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new RecyclerScreenHandler(syncId, playerInventory, this, propertyDelegate);
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registryLookup) {
        super.method_11007(nbt, registryLookup);
        class_1262.method_5426(nbt, inventory, registryLookup);
        nbt.method_10569("recycler.progress", progress);
        nbt.method_10569("recycler.max_progress", maxProgress);
        nbt.method_10544("recycler.energy", energyStorage.amount);
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registryLookup) {
        class_1262.method_5429(nbt, inventory, registryLookup);
        progress = nbt.method_10550("recycler.progress");
        maxProgress = nbt.method_10550("recycler.max_progress");
        energyStorage.amount = nbt.method_10537("recycler.energy");
        super.method_11014(nbt, registryLookup);
    }

    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if (hasRecipe() && canInsertIntoOutputSlot()) {
            increaseCraftingProgress();
            world.method_8501(pos, state.method_11657(Recycler.LIT, true));

            if (hasCraftingFinished()) {
                craftItem();
                resetProgress();
            }
        } else {
            world.method_8501(pos, state.method_11657(Recycler.LIT, false));
            resetProgress();
        }
        method_31663(world, pos, state);
    }

    private void resetProgress() {
        this.progress = 0;
        this.maxProgress = DEFAULT_MAX_PROGRESS;
    }

    private void craftItem() {
        Optional<class_8786<RecyclerRecipe>> recipe = getCurrentRecipe();

        this.method_5434(INPUT_SLOT, 1);
        this.method_5447(OUTPUT_SLOT, new class_1799(recipe.get().comp_1933().output().method_7909(),
                this.method_5438(OUTPUT_SLOT).method_7947() + recipe.get().comp_1933().method_8110(null).method_7947()));
    }

    private boolean hasCraftingFinished() {
        Optional<class_8786<RecyclerRecipe>> recipe = getCurrentRecipe();
        return this.progress >= this.maxProgress;
    }

    private void increaseCraftingProgress() {
        if (!hasEnoughEnergy(ENERGY_CRAFTING_AMOUNT)) {
            this.progress++;
            try (Transaction transaction = Transaction.openOuter()) {
                this.energyStorage.extract(ENERGY_CRAFTING_AMOUNT, transaction);
                transaction.commit();
            }
        }
    }

    private boolean canInsertIntoOutputSlot() {
        return this.method_5438(OUTPUT_SLOT).method_7960() ||
                this.method_5438(OUTPUT_SLOT).method_7947() < this.method_5438(OUTPUT_SLOT).method_7914();
    }

    private boolean hasRecipe() {
        Optional<class_8786<RecyclerRecipe>> recipe = getCurrentRecipe();

        if (recipe.isEmpty()){
            return false;
        }

        class_1799 output = recipe.get().comp_1933().method_8110(null);

        this.maxProgress = recipe.get().comp_1933().getCookingTime();

        return canInsertAmountIntoOutputSlot(output.method_7947()) && canInsertItemIntoOutputSlot(output);
    }

    private boolean hasEnoughEnergy(int amount) {
        return amount >= this.energyStorage.amount;
    }

    private Optional<class_8786<RecyclerRecipe>> getCurrentRecipe() {
        return this.method_10997().method_8433().method_8132(ModRecipes.RECYCLER_TYPE, new RecyclerRecipeInput(inventory.get(INPUT_SLOT)), this.field_11863);
    }

    private boolean canInsertItemIntoOutputSlot(class_1799 output) {
        return this.method_5438(OUTPUT_SLOT).method_7909() == output.method_7909() || this.method_5438(OUTPUT_SLOT).method_7960();
    }

    private boolean canInsertAmountIntoOutputSlot(int count) {
        return this.method_5438(OUTPUT_SLOT).method_7914() >= this.method_5438(OUTPUT_SLOT).method_7947() + count;
    }


    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return this.method_38244(registryLookup);
    }
}
