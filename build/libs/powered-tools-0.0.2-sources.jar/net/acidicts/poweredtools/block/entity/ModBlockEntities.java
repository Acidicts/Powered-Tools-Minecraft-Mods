package net.acidicts.poweredtools.block.entity;

import net.acidicts.poweredtools.PoweredTools;
import net.acidicts.poweredtools.block.ModBlocks;
import net.acidicts.poweredtools.block.custom.Recycler;
import net.acidicts.poweredtools.block.entity.custom.AlloySmelterBlockEntity;
import net.acidicts.poweredtools.block.entity.custom.ChargerBlockEntity;
import net.acidicts.poweredtools.block.entity.custom.CoalGeneratorBlockEntity;
import net.acidicts.poweredtools.block.entity.custom.RecyclerBlockEntity;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import team.reborn.energy.api.EnergyStorage;

public class ModBlockEntities {
    public static final class_2591<ChargerBlockEntity> CHARGER_BLOCK_ENTITY =
            class_2378.method_10230(
                    class_7923.field_41181,
                    class_2960.method_60655(PoweredTools.MOD_ID, "charger_block_entity"),
                    class_2591.class_2592.method_20528(ChargerBlockEntity::new, ModBlocks.CHARGER).method_11034(null)
            );

    public static final class_2591<RecyclerBlockEntity> RECYCLER_BLOCK_ENTITY =
            class_2378.method_10230(
                    class_7923.field_41181,
                    class_2960.method_60655(PoweredTools.MOD_ID, "recycler_block_entity"),
                    class_2591.class_2592.method_20528(RecyclerBlockEntity::new, ModBlocks.RECYCLER).method_11034(null)
            );

    public static final class_2591<CoalGeneratorBlockEntity> COAL_GENERATOR_BLOCK_ENTITY =
            class_2378.method_10230(
                    class_7923.field_41181,
                    class_2960.method_60655(PoweredTools.MOD_ID, "coal_generator_block_entity"),
                    class_2591.class_2592.method_20528(CoalGeneratorBlockEntity::new, ModBlocks.COAL_GENERATOR).method_11034(null)
            );

    public static final class_2591<AlloySmelterBlockEntity> ALLOY_SMELTER_BLOCK_ENTITY =
            class_2378.method_10230(
                    class_7923.field_41181,
                    class_2960.method_60655(PoweredTools.MOD_ID, "alloy_smelter_block_entity"),
                    class_2591.class_2592.method_20528(AlloySmelterBlockEntity::new, ModBlocks.ALLOY_SMELTER).method_11034(null)
            );


    public static void registerBlockEntities() {
        PoweredTools.LOGGER.info("Registering Block Entities for {}", PoweredTools.MOD_ID);

        EnergyStorage.SIDED.registerForBlockEntity((blockEntity, direction) -> blockEntity.energyStorage, COAL_GENERATOR_BLOCK_ENTITY);
        EnergyStorage.SIDED.registerForBlockEntity((blockEntity, direction) -> blockEntity.energyStorage, RECYCLER_BLOCK_ENTITY);
        EnergyStorage.SIDED.registerForBlockEntity((blockEntity, direction) -> blockEntity.energyStorage, ALLOY_SMELTER_BLOCK_ENTITY);
    }
}

