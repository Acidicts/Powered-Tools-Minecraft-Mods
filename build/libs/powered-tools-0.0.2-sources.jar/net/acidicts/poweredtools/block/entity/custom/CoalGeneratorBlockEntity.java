package net.acidicts.poweredtools.block.entity.custom;

import net.acidicts.poweredtools.block.entity.ImplementedInventory;
import net.acidicts.poweredtools.block.entity.ModBlockEntities;
import net.acidicts.poweredtools.data.Burnables;
import net.acidicts.poweredtools.screen.custom.coal_generator.CoalGeneratorScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1262;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3913;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;
import team.reborn.energy.api.EnergyStorage;
import team.reborn.energy.api.EnergyStorageUtil;
import team.reborn.energy.api.base.SimpleEnergyStorage;

public class CoalGeneratorBlockEntity extends class_2586 implements ExtendedScreenHandlerFactory<class_2338>, ImplementedInventory {
    private final class_2371<class_1799> inventory = class_2371.method_10213(1, class_1799.field_8037);

    private static final int INPUT_SLOT = 0;

    protected final class_3913 propertyDelegate;
    private class_1792 fuelItem;
    private int burnProgress = 0;
    private int maxBurnProgress = 160;
    private boolean isBurning = false;
    private Burnables burnables = new Burnables();

    private static final int ENERGY_TRANSFER_AMOUNT = 320;

    public final SimpleEnergyStorage energyStorage = new SimpleEnergyStorage(128000, ENERGY_TRANSFER_AMOUNT, ENERGY_TRANSFER_AMOUNT) {
        @Override
        protected void onFinalCommit() {
            method_5431();
            method_10997().method_8413(field_11867, method_11010(), method_11010(), 3);
        }
    };

    public CoalGeneratorBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.COAL_GENERATOR_BLOCK_ENTITY, pos, state);

        this.propertyDelegate = new class_3913() {
            @Override
            public int method_17390(int index) {
                return switch (index) {
                    case 0 -> CoalGeneratorBlockEntity.this.burnProgress;
                    case 1 -> CoalGeneratorBlockEntity.this.maxBurnProgress;
                    default -> 0;
                };
            }

            @Override
            public void method_17391(int index, int value) {
                switch (index) {
                    case 0: CoalGeneratorBlockEntity.this.burnProgress = value;
                    case 1: CoalGeneratorBlockEntity.this.maxBurnProgress = value;
                }
            }

            @Override
            public int method_17389() {
                return 2;
            }
        };
    }

    @Override
    public class_2371<class_1799> getItems() {
        return this.inventory;
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registryLookup) {
        super.method_11007(nbt, registryLookup);
        class_1262.method_5426(nbt, inventory, registryLookup);
        nbt.method_10544(("coal_generator_energy"), energyStorage.amount);
        nbt.method_10569(("coal_generator_burn_progress"), burnProgress);
        nbt.method_10569(("coal_generator_max_burn_progress"), burnProgress);
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registryLookup) {
        class_1262.method_5429(nbt, inventory, registryLookup);
        energyStorage.amount = nbt.method_10537("coal_generator_energy");
        burnProgress = nbt.method_10550("coal_generator_burn_progress");
        maxBurnProgress = nbt.method_10550("coal_generator_max_burn_progress");
        super.method_11014(nbt, registryLookup);
    }

    @Override
    public class_2338 getScreenOpeningData(class_3222 serverPlayerEntity) {
        return this.field_11867;
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43470("Coal Generator");
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new CoalGeneratorScreenHandler(syncId, playerInventory, this, this.propertyDelegate);
    }

    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if (world.method_8608()) {
            return;
        }

        if (hasFuelItemInSlot()) {
            if(!isBurningFuel()) {
                startBurning();
            }
        }

        if (isBurningFuel()) {
            if (hasRoomForEnergyTick()) {
                increaseBurnTimer();
                fillUpOnEnergy();
                if (currentFuelDoneBurning()) {
                    resetBurning();
                }
            }
        }

        pushEnergyToNeighbours();
    }

    private void pushEnergyToNeighbours() {
        EnergyStorageUtil.move(this.energyStorage, EnergyStorage.SIDED.find(field_11863, field_11867.method_10084(), null), Long.MAX_VALUE, null);
        EnergyStorageUtil.move(this.energyStorage, EnergyStorage.SIDED.find(field_11863, field_11867.method_10074(), null), Long.MAX_VALUE, null);
        EnergyStorageUtil.move(this.energyStorage, EnergyStorage.SIDED.find(field_11863, field_11867.method_10078(), null), Long.MAX_VALUE, null);
        EnergyStorageUtil.move(this.energyStorage, EnergyStorage.SIDED.find(field_11863, field_11867.method_10067(), null), Long.MAX_VALUE, null);
        EnergyStorageUtil.move(this.energyStorage, EnergyStorage.SIDED.find(field_11863, field_11867.method_10095(), null), Long.MAX_VALUE, null);
        EnergyStorageUtil.move(this.energyStorage, EnergyStorage.SIDED.find(field_11863, field_11867.method_10072(), null), Long.MAX_VALUE, null);
    }

    private void fillUpOnEnergy() {
        if (fuelItem == null) {
            return;
        }

        int energyToAdd = burnables.getEnergyValue(fuelItem, this.maxBurnProgress);
        if (energyToAdd <= 0) {
            return;
        }

        try (Transaction transaction = Transaction.openOuter()){
            energyStorage.insert(energyToAdd, transaction);
            transaction.commit();
        }
    }

    private void resetBurning() {
        isBurning = false;
        fuelItem = null;
        this.burnProgress = maxBurnProgress;
    }

    private boolean currentFuelDoneBurning() {
        return this.burnProgress <= (int) 0 ;
    }

    private void increaseBurnTimer() {
        int time = burnables.getEnergyValue(this.method_5438(INPUT_SLOT).method_7909(), 1) / ENERGY_TRANSFER_AMOUNT;
        int diff = burnables.getEnergyValue(this.method_5438(INPUT_SLOT).method_7909(), time);
        if (energyStorage.amount + diff <= energyStorage.capacity) {
            burnProgress++;
        }
    }

    private boolean hasRoomForEnergyTick() {
        if (fuelItem == null) {
            return false;
        }

        int energyToAdd = burnables.getEnergyValue(fuelItem, this.maxBurnProgress);
        return energyStorage.amount + energyToAdd <= energyStorage.capacity;
    }

    private void startBurning() {
        fuelItem = this.method_5438(INPUT_SLOT).method_7909();
        this.method_5434(INPUT_SLOT, 1);
        isBurning = true;
    }

    private boolean isBurningFuel() {
        return isBurning;
    }

    private boolean hasFuelItemInSlot() {
        this.burnProgress = burnables.getEnergyValue(this.method_5438(INPUT_SLOT).method_7909(), 1) / ENERGY_TRANSFER_AMOUNT;
        return burnables.getEnergyValue(this.method_5438(INPUT_SLOT).method_7909(), 1) != 0;
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_38244(registryLookup);
    }
}
