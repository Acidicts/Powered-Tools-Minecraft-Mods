package net.acidicts.poweredtools.block.entity.custom;

import net.acidicts.poweredtools.block.custom.AlloySmelter;
import net.acidicts.poweredtools.block.entity.ImplementedInventory;
import net.acidicts.poweredtools.block.entity.ModBlockEntities;
import net.acidicts.poweredtools.recipe.ModRecipes;
import net.acidicts.poweredtools.recipe.alloy_smelter.AlloySmelterRecipe;
import net.acidicts.poweredtools.recipe.alloy_smelter.AlloySmelterRecipeInput;
import net.acidicts.poweredtools.screen.custom.alloy_smelter.recycler.AlloySmelterScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1262;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3913;
import net.minecraft.class_7225;
import net.minecraft.class_8786;
import org.jetbrains.annotations.Nullable;
import team.reborn.energy.api.base.SimpleEnergyStorage;

import java.util.Map;
import java.util.Optional;

public class AlloySmelterBlockEntity extends class_2586 implements ExtendedScreenHandlerFactory<class_2338>, ImplementedInventory {
    private final class_2371<class_1799> inventory = class_2371.method_10213(5, class_1799.field_8037);

    private static final int INPUT_SLOT_0 = 0;
    private static final int INPUT_SLOT_1 = 1;
    private static final int INPUT_SLOT_2 = 2;
    private static final int OUTPUT_SLOT = 3;
    private static final int Energy_ITEM_SLOT = 4;

    protected final class_3913 propertyDelegate;
    private int progress = 0;
    private int maxProgress = 72;
    private final int DEFAULT_MAX_PROGRESS = 72;

    private static final int ENERGY_CRAFTING_AMOUNT = 50;
    private static final int ENERGY_TRANSFER_AMOUNT = 320;

    public final SimpleEnergyStorage energyStorage = new SimpleEnergyStorage(64000, ENERGY_TRANSFER_AMOUNT, ENERGY_TRANSFER_AMOUNT) {
        @Override
        protected void onFinalCommit() {
            method_5431();
            method_10997().method_8413(field_11867, method_11010(), method_11010(), 3);
        }
    };

    public AlloySmelterBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.ALLOY_SMELTER_BLOCK_ENTITY, pos, state);
        this.propertyDelegate = new class_3913() {
            @Override
            public int method_17390(int index) {
                return switch (index) {
                    case 0 -> AlloySmelterBlockEntity.this.progress;
                    case 1 -> AlloySmelterBlockEntity.this.maxProgress;
                    default -> 0;
                };
            }

            @Override
            public void method_17391(int index, int value) {
                switch (index) {
                    case 0: AlloySmelterBlockEntity.this.progress = value;
                    case 1: AlloySmelterBlockEntity.this.maxProgress = value;
                }
            }

            @Override
            public int method_17389() {
                return 2;
            }
        };
    }

    @Override
    public boolean method_5492(int slot, class_1799 stack, @Nullable class_2350 side) {
        assert this.method_10997() != null;
        class_2350 localDir = this.method_10997().method_8320(field_11867).method_11654(AlloySmelter.FACING);

        if (side == null) {
            return false;
        }

        if (side == class_2350.field_11033) {
            return false;
        }

        if (side == class_2350.field_11036) {
            return slot == INPUT_SLOT_1;
        }

        class_2350 right = localDir.method_10170();
        class_2350 left = localDir.method_10160();

        if (side == right) {
            return slot == INPUT_SLOT_2;
        } else if (side == left) {
            return slot == INPUT_SLOT_0;
        }

        return false;
    }

    @Override
    public boolean method_5493(int slot, class_1799 stack, class_2350 side) {
        assert this.method_10997() != null;
        class_2350 localDir = this.method_10997().method_8320(field_11867).method_11654(AlloySmelter.FACING);

        if (side == class_2350.field_11033) {
            return slot == OUTPUT_SLOT;
        }

        return false;
    }

    @Override
    public class_2371<class_1799> getItems() {
        return inventory;
    }

    @Override
    public class_2338 getScreenOpeningData(class_3222 player) {
        return this.field_11867;
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471("gui.poweredtools.recycler");
    }

    @Override
    public @Nullable class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new AlloySmelterScreenHandler(syncId, playerInventory, this, propertyDelegate);
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registryLookup) {
        super.method_11007(nbt, registryLookup);
        class_1262.method_5426(nbt, inventory, registryLookup);
        nbt.method_10569("alloyer.progress", progress);
        nbt.method_10569("alloyer.max_progress", maxProgress);
        nbt.method_10544("alloyer.energy", energyStorage.amount);
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registryLookup) {
        class_1262.method_5429(nbt, inventory, registryLookup);
        progress = nbt.method_10550("alloyer.progress");
        maxProgress = nbt.method_10550("alloyer.max_progress");
        energyStorage.amount = nbt.method_10537("alloyer.energy");
        super.method_11014(nbt, registryLookup);
    }

    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if (hasRecipe() && canInsertIntoOutputSlot()) {
            increaseCraftingProgress();
            world.method_8501(pos, state.method_11657(AlloySmelter.LIT, true));

            if (hasCraftingFinished()) {
                craftItem();
                resetProgress();
            }
        } else {
            world.method_8501(pos, state.method_11657(AlloySmelter.LIT, false));
            resetProgress();
        }
        method_31663(world, pos, state);
    }

    private void resetProgress() {
        this.progress = 0;
        this.maxProgress = DEFAULT_MAX_PROGRESS;
    }

    private Map<Integer, Boolean> getInputSlotsStatus() {
        return Map.of(
                INPUT_SLOT_0, !this.method_5438(INPUT_SLOT_0).method_7960(),
                INPUT_SLOT_1, !this.method_5438(INPUT_SLOT_1).method_7960(),
                INPUT_SLOT_2, !this.method_5438(INPUT_SLOT_2).method_7960()
        );
    }

    private void craftItem() {
        Optional<class_8786<AlloySmelterRecipe>> recipe = getCurrentRecipe();

        for (Map.Entry<Integer, Boolean> entry : getInputSlotsStatus().entrySet()) {
            if (entry.getValue()) {
                this.method_5434(entry.getKey(), 1);
            }
        }
        this.method_5447(OUTPUT_SLOT, new class_1799(recipe.get().comp_1933().output().method_7909(),
                this.method_5438(OUTPUT_SLOT).method_7947() + recipe.get().comp_1933().method_8110(null).method_7947()));
    }

    private boolean hasCraftingFinished() {
        Optional<class_8786<AlloySmelterRecipe>> recipe = getCurrentRecipe();
        return this.progress >= this.maxProgress;
    }

    private void increaseCraftingProgress() {
        if (hasEnoughEnergy(ENERGY_CRAFTING_AMOUNT)) {
            this.progress++;
            try (Transaction transaction = Transaction.openOuter()) {
                this.energyStorage.extract(ENERGY_CRAFTING_AMOUNT, transaction);
                transaction.commit();
            }
        }
    }

    private boolean canInsertIntoOutputSlot() {
        return this.method_5438(OUTPUT_SLOT).method_7960() ||
                this.method_5438(OUTPUT_SLOT).method_7947() < this.method_5438(OUTPUT_SLOT).method_7914();
    }

    private boolean hasRecipe() {
        Optional<class_8786<AlloySmelterRecipe>> recipe = getCurrentRecipe();

        if (recipe.isEmpty()){
            return false;
        }

        class_1799 output = recipe.get().comp_1933().method_8110(null);

        this.maxProgress = recipe.get().comp_1933().getCookingTime();

        return canInsertAmountIntoOutputSlot(output.method_7947()) && canInsertItemIntoOutputSlot(output);
    }

    private boolean hasEnoughEnergy(int amount) {
        return this.energyStorage.amount >= amount;
    }

    private Optional<class_8786<AlloySmelterRecipe>> getCurrentRecipe() {
        assert this.method_10997() != null;
        return this.method_10997().method_8433().method_8132(ModRecipes.ALLOYING_TYPE, new AlloySmelterRecipeInput(inventory.get(INPUT_SLOT_0), inventory.get(INPUT_SLOT_1), inventory.get(INPUT_SLOT_2)), this.field_11863);
    }

    private boolean canInsertItemIntoOutputSlot(class_1799 output) {
        return this.method_5438(OUTPUT_SLOT).method_7909() == output.method_7909() || this.method_5438(OUTPUT_SLOT).method_7960();
    }

    private boolean canInsertAmountIntoOutputSlot(int count) {
        return this.method_5438(OUTPUT_SLOT).method_7914() >= this.method_5438(OUTPUT_SLOT).method_7947() + count;
    }


    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return this.method_38244(registryLookup);
    }
}
