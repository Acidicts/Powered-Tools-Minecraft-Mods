package net.acidicts.poweredtools.block.entity.renderer.charger;

import net.acidicts.poweredtools.PoweredTools;
import net.acidicts.poweredtools.block.entity.custom.ChargerBlockEntity;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;

public class ChargerBlockModel extends GeoModel<ChargerBlockEntity> {
    @Override
    public class_2960 getModelResource(ChargerBlockEntity animatable) {
        return class_2960.method_60655(PoweredTools.MOD_ID, "geo/charger.geo.json");
    }

    @Override
    public class_2960 getTextureResource(ChargerBlockEntity animatable) {
        return class_2960.method_60655(PoweredTools.MOD_ID, "textures/entity/charger.png");
    }

    @Override
    public class_2960 getAnimationResource(ChargerBlockEntity animatable) {
        return class_2960.method_60655(PoweredTools.MOD_ID, "animations/charger.animation.json");
    }
}

