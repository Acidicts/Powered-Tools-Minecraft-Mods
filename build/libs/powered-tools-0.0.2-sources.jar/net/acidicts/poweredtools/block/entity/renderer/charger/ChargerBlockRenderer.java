package net.acidicts.poweredtools.block.entity.renderer.charger;

import net.acidicts.poweredtools.block.entity.custom.ChargerBlockEntity;
import net.minecraft.class_5614;
import software.bernie.geckolib.renderer.GeoBlockRenderer;

public class ChargerBlockRenderer extends GeoBlockRenderer<ChargerBlockEntity> {
    public ChargerBlockRenderer(class_5614.class_5615 context) {
        super(new ChargerBlockModel());
    }
}

