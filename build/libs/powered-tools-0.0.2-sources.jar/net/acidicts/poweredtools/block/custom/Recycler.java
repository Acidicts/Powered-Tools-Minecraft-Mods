package net.acidicts.poweredtools.block.custom;

import com.mojang.serialization.MapCodec;
import net.acidicts.poweredtools.block.entity.ModBlockEntities;
import net.acidicts.poweredtools.block.entity.custom.RecyclerBlockEntity;
import net.minecraft.block.*;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2392;
import net.minecraft.class_2398;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3908;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import net.minecraft.class_9062;
import net.minecraft.util.*;
import org.jetbrains.annotations.Nullable;


public class Recycler extends class_2237 {
    public static final MapCodec<Recycler> CODEC = method_54094(Recycler::new);
    public static final class_2746 LIT = class_2741.field_12548;
    public static final class_2753 FACING = class_2383.field_11177;

    public Recycler(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664().method_11657(FACING, class_2350.field_11043));
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, LIT);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new RecyclerBlockEntity(pos, state);
    }

    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    protected void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        if (state.method_26204() != newState.method_26204()) {
            if (world.method_8321(pos) instanceof RecyclerBlockEntity recyclerBlockEntity) {
                class_1264.method_5451(world, pos, recyclerBlockEntity);
                world.method_8455(pos, this);
            }
            super.method_9536(state, world, pos, newState, moved);
        }
    }

    @Override
    protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (!world.field_9236) {
            class_3908 screenHandlerFactory = ((RecyclerBlockEntity) world.method_8321(pos));

            if (screenHandlerFactory != null) {
                player.method_17355(screenHandlerFactory);
            }
        }
        return class_9062.field_47728;
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return method_31618(type, ModBlockEntities.RECYCLER_BLOCK_ENTITY, (world1, pos, state1, blockEntity) -> blockEntity.tick(world1, pos, state1));
    }

    @Override
    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 random) {
        if (!state.method_11654(LIT)) {
            return;
        }

        double x = pos.method_10263() + 0.5;
        double y = pos.method_10264();
        double z = pos.method_10260() + 0.5;
        if (random.method_43058() < 0.1) {
            world.method_8486(x, y, z, class_3417.field_14557, class_3419.field_15245, 1.0f, 1.0f, false);
        }

        class_2350 direction = state.method_11654(FACING);
        class_2350.class_2351 axis = direction.method_10166();

        double defaultOffset = random.method_43058() * 0.6 -0.3;
        double xOffsets = axis == class_2350.class_2351.field_11048 ? (double) direction.method_10148() * 0.52 : defaultOffset;
        double yOffsets = random.method_43058() * 6.0 / 8.0;
        double zOffsets = axis == class_2350.class_2351.field_11051 ? (double) direction.method_10165() * 0.52 : defaultOffset;

        world.method_8406(class_2398.field_11251, x + xOffsets, y + yOffsets, z + zOffsets, 0.0, 0.0, 0.0);

        if (world.method_8321(pos) instanceof RecyclerBlockEntity recyclerBlockEntity && !recyclerBlockEntity.method_5438(1).method_7960()) {
            world.method_8406(new class_2392(class_2398.field_11218, recyclerBlockEntity.method_5438(1)),
                    x + xOffsets, y + yOffsets, z + zOffsets,0.0, 0.0, 0.0);
        }
    }
}
