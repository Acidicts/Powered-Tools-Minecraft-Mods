package net.acidicts.poweredtools.block.custom;

import com.mojang.serialization.MapCodec;
import net.acidicts.poweredtools.PoweredTools;
import net.acidicts.poweredtools.block.entity.custom.ChargerBlockEntity;
import net.acidicts.poweredtools.item.ModItems;
import net.acidicts.poweredtools.item.custom.BatteryItem;
import net.acidicts.poweredtools.item.custom.Powered_Pickaxe;
import net.acidicts.poweredtools.particle.ModParticles;
import net.acidicts.poweredtools.tags.ModTags;
import net.minecraft.block.*;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1920;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2753;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

public class Charger extends class_2237 {
    public static final MapCodec<Charger> CODEC = method_54094(Charger::new);
    public static final class_2753 FACING = class_2383.field_11177;

    public Charger(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664().method_11657(FACING, class_2350.field_11043));
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new ChargerBlockEntity(pos, state);
    }

    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return world.field_9236 ? null : (world1, pos, state1, blockEntity) -> {
            if (blockEntity instanceof ChargerBlockEntity charger) {
                charger.tick();
            }
        };
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11456;
    }

    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState,
                                                  class_1936 world, class_2338 pos, class_2338 neighborPos) {
        // Trigger block entity update when neighbors change
        if (!world.method_8608()) {
            class_2586 blockEntity = world.method_8321(pos);
            if (blockEntity instanceof ChargerBlockEntity chargerEntity) {
                // Mark the block entity as needing a sync to update the animation
                chargerEntity.method_5431();
            }
        }
        return super.method_9559(state, direction, neighborState, world, pos, neighborPos);
    }

    @Override
    public class_2680 getAppearance(class_2680 state, class_1920 renderView, class_2338 pos, class_2350 side, @Nullable class_2680 sourceState, @Nullable class_2338 sourcePos) {
        return super.getAppearance(state, renderView, pos, side, sourceState, sourcePos);
    }

    @Override
    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 random) {
        createParticles(world, pos);
    }

    private void createParticles(class_1937 world, class_2338 pos) {
        for (int i = 0; i < 2; i++) {
            double xPos = pos.method_10263() + 0.5;
            double yPos = pos.method_10264() + 0.5;
            double zPos = pos.method_10260() + 0.5;
            double offset = Math.random() * 0.6 - 0.3;
            double velocity_x = Math.random() * 0.1 + 0.02;
            double velocity_y = Math.abs(Math.random() * 0.1 + 0.02);
            double velocity_z = Math.random() * 0.1 + 0.02;

            if (randomBoolean()) velocity_x = -velocity_x;
            if (randomBoolean()) velocity_y = -velocity_y;
            if (randomBoolean()) velocity_z = -velocity_z;

            world.method_8406(ModParticles.ELECTRIC_SPARK, xPos + offset, yPos, zPos + offset, velocity_x, velocity_y, velocity_z);
        }
    }

    private boolean randomBoolean() {
        return Math.random() < 0.5;
    }

    @Override
    public class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        class_2586 blockEntity = world.method_8321(pos);
        if (blockEntity instanceof ChargerBlockEntity) {
            if (!((ChargerBlockEntity) blockEntity).hasSpaceToOpen() && !((ChargerBlockEntity) blockEntity).hasOpened()) {
                player.method_7353(class_2561.method_43470("Place the Charger Without Blocks around it to open it!").method_27692(class_124.field_1061), true);
                return class_1269.field_5814;
            }
        }
        if (((ChargerBlockEntity) blockEntity).hasOpened()) {
            createParticles(world, pos);
        }
        if (world.field_9236 && player.method_6047().method_31573(ModTags.Items.chargeable)) {
            var stack = player.method_6047();


            if (stack.method_7909() instanceof BatteryItem batteryItem) {
                int maxCapacity = batteryItem.getMaxCapacity(stack);
                int currentCharge = batteryItem.getCurrentCharge(stack);
                int rechargeAmount = maxCapacity - currentCharge;

                if (batteryItem.isBroken(stack)) {
                    int slot = player.method_31548().method_7395(stack);
                    player.method_31548().method_5441(slot);
                    class_1792 brokenBattery = ModItems.getBrokenBatteryByTier((String) batteryItem.getTier(stack, "string"));
                    player.method_31548().method_7394(brokenBattery.method_7854());
                }

                if (rechargeAmount > 0) {
                    batteryItem.recharge(stack, rechargeAmount);
                    return class_1269.field_5812;
                }
            }
        }


        return class_1269.field_5811;
    }
}
