package net.acidicts.poweredtools.tags;

import net.acidicts.poweredtools.PoweredTools;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class ModTags {
    public static class Items {
        public static final class_6862<class_1792> chargeable = createTagKey("chargeable");

        private static class_6862<class_1792> createTagKey(String name) {
            return class_6862.method_40092(class_7924.field_41197, class_2960.method_60655(PoweredTools.MOD_ID, name));
        }
    }
    public static class Blocks {


        private static class_6862<class_2248> createTagKey(String name) {
            return class_6862.method_40092(class_7924.field_41254, class_2960.method_60655(PoweredTools.MOD_ID, name));
        }
    }
}
