package net.acidicts.poweredtools;

import net.acidicts.poweredtools.block.entity.ModBlockEntities;
import net.acidicts.poweredtools.block.entity.renderer.charger.ChargerBlockRenderer;
import net.acidicts.poweredtools.particle.ModParticles;
import net.acidicts.poweredtools.screen.ModScreenHandlers;
import net.acidicts.poweredtools.screen.custom.alloy_smelter.recycler.AlloySmelterScreen;
import net.acidicts.poweredtools.screen.custom.coal_generator.CoalGeneratorScreen;
import net.acidicts.poweredtools.screen.custom.recycler.RecyclerScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.minecraft.class_3929;
import net.minecraft.class_5616;
import net.minecraft.class_687;

public class PoweredToolsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        class_5616.method_32144(ModBlockEntities.CHARGER_BLOCK_ENTITY, ChargerBlockRenderer::new);

        class_3929.method_17542(ModScreenHandlers.RECYCLER_SCREEN_HANDLER, RecyclerScreen::new);
        class_3929.method_17542(ModScreenHandlers.ALLOY_SMELTER_SCREEN_HANDLER, AlloySmelterScreen::new);
        class_3929.method_17542(ModScreenHandlers.COAL_GENERATOR_SCREEN_HANDLER, CoalGeneratorScreen::new);

        ParticleFactoryRegistry.getInstance().register(ModParticles.ELECTRIC_SPARK, class_687.class_688::new);
    }
}

