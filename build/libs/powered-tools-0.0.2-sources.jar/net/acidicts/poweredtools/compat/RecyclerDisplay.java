package net.acidicts.poweredtools.compat;

import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.display.basic.BasicDisplay;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import me.shedaniel.rei.api.common.util.EntryIngredients;
import me.shedaniel.rei.api.common.util.EntryStacks;
import net.acidicts.poweredtools.recipe.recycler.RecyclerRecipe;
import net.minecraft.class_8786;
import java.util.List;

public class RecyclerDisplay extends BasicDisplay {


    public RecyclerDisplay(class_8786<RecyclerRecipe> recipe) {
        super(List.of(EntryIngredients.ofIngredient(recipe.comp_1933().method_8117().getFirst())),
                List.of(EntryIngredient.of(EntryStacks.of(recipe.comp_1933().method_8110(null)))));
    }

    @Override
    public CategoryIdentifier<?> getCategoryIdentifier() {
        return RecyclerCategory.RECYCLER;
    }
}
