package net.acidicts.poweredtools.datagen;


import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.SimpleFabricLootTableProvider;
import net.minecraft.class_173;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;

public class ModEntityLootTableProvider extends SimpleFabricLootTableProvider {
    public ModEntityLootTableProvider(FabricDataOutput dataOutput, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataOutput, registryLookup, class_173.field_1173);
    }

    @Override
    public void method_10399(BiConsumer<class_5321<class_52>, class_52.class_53> consumer) {

    }
}