package net.acidicts.poweredtools.datagen;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.acidicts.poweredtools.PoweredTools;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_2405;
import net.minecraft.class_2960;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class ModParticleProvider implements class_2405 {
    private final class_7784.class_7489 pathResolver;

    public ModParticleProvider(FabricDataOutput output) {
        this.pathResolver = output.method_45973(class_7784.class_7490.field_39368, "particles");
    }

    @Override
    public CompletableFuture<?> method_10319(class_7403 writer) {
        List<CompletableFuture<?>> futures = new ArrayList<>();

        futures.add(generateParticle(writer, "electric_spark",
            List.of(PoweredTools.MOD_ID + ":electric_spark")));

        return CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]));
    }

    private CompletableFuture<?> generateParticle(class_7403 writer, String name, List<String> textures) {
        JsonObject json = new JsonObject();
        JsonArray texturesArray = new JsonArray();

        for (String texture : textures) {
            texturesArray.add(texture);
        }

        json.add("textures", texturesArray);

        Path path = this.pathResolver.method_44107(class_2960.method_60655(PoweredTools.MOD_ID, name));
        return class_2405.method_10320(writer, json, path);
    }

    @Override
    public String method_10321() {
        return "Particle Definitions";
    }
}

