package net.acidicts.poweredtools.datagen;

import me.shedaniel.errornotifier.launch.early.Texture;
import net.acidicts.poweredtools.block.ModBlocks;
import net.acidicts.poweredtools.block.custom.Recycler;
import net.acidicts.poweredtools.item.ModItems;
import net.acidicts.poweredtools.item.custom.BatteryItem;
import net.acidicts.poweredtools.item.custom.BrokenBatteryItem;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4943;
import net.minecraft.data.client.*;
import java.util.List;


public class ModModelProvider extends FabricModelProvider {
    public final List<BatteryItem> batteryItems = List.of(
            (BatteryItem) ModItems.BATTERY_TIER_0,
            (BatteryItem) ModItems.BATTERY_TIER_1,
            (BatteryItem) ModItems.BATTERY_TIER_2,
            (BatteryItem) ModItems.BATTERY_TIER_3,
            (BatteryItem) ModItems.BATTERY_TIER_4,
            (BatteryItem) ModItems.BATTERY_TIER_5
    );
    public final List<BrokenBatteryItem> brokenBatteryItems = List.of(
            (BrokenBatteryItem) ModItems.BROKEN_BATTERY_TIER_0,
            (BrokenBatteryItem) ModItems.BROKEN_BATTERY_TIER_1,
            (BrokenBatteryItem) ModItems.BROKEN_BATTERY_TIER_2,
            (BrokenBatteryItem) ModItems.BROKEN_BATTERY_TIER_3,
            (BrokenBatteryItem) ModItems.BROKEN_BATTERY_TIER_4,
            (BrokenBatteryItem) ModItems.BROKEN_BATTERY_TIER_5
    );


    public ModModelProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator) {

        blockStateModelGenerator.method_25708(ModBlocks.COAL_GENERATOR);
        blockStateModelGenerator.method_25708(ModBlocks.ALLOY_SMELTER);
    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {
        itemModelGenerator.method_25733(ModItems.POWERED_PICKAXE, class_4943.field_22939);

        for (BatteryItem battery : batteryItems) {
            itemModelGenerator.method_25733(battery, class_4943.field_22938);
        }
        for (BrokenBatteryItem brokenBattery : brokenBatteryItems) {
            itemModelGenerator.method_25733(brokenBattery, class_4943.field_22938);
        }
    }
}
