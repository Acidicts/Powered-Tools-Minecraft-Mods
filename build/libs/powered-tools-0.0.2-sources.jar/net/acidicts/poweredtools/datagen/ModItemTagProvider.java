package net.acidicts.poweredtools.datagen;

import net.acidicts.poweredtools.item.ModItems;
import net.acidicts.poweredtools.tags.ModTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class ModItemTagProvider extends FabricTagProvider.ItemTagProvider {
    public ModItemTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(output, completableFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 wrapperLookup) {
        method_10512(ModTags.Items.chargeable)
                .add(ModItems.BATTERY_TIER_0)
                .add(ModItems.BATTERY_TIER_1)
                .add(ModItems.BATTERY_TIER_2)
                .add(ModItems.BATTERY_TIER_3)
                .add(ModItems.BATTERY_TIER_4)
                .add(ModItems.BATTERY_TIER_5);
    }
}
