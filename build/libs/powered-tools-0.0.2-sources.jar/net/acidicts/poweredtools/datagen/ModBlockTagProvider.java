package net.acidicts.poweredtools.datagen;

import net.acidicts.poweredtools.block.ModBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_3481;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class ModBlockTagProvider extends FabricTagProvider.BlockTagProvider {

    public ModBlockTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 wrapperLookup) {
        method_10512(class_3481.field_33718).add(ModBlocks.CHARGER);
        method_10512(class_3481.field_33715).add(ModBlocks.CHARGER);
    }
}
