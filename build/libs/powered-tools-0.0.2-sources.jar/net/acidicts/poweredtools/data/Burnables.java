package net.acidicts.poweredtools.data;

import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_3489;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class Burnables {
    public Map<class_1792, Integer> map2 = Maps.newLinkedHashMap();

    public Burnables() {

        addFuel(map2, class_1802.field_8187, 20000);
        addFuel(map2, class_2246.field_10381, 16000);
        addFuel(map2, class_1802.field_8894, 2400);
        addFuel(map2, class_1802.field_8713, 1600);
        addFuel(map2, class_1802.field_8665, 1600);
        addFuel(map2, class_3489.field_15539, 300);
        addFuel(map2, class_3489.field_40987, 300);
        addFuel(map2, class_3489.field_15537, 300);
        addFuel(map2, class_2246.field_40295, 300);
        addFuel(map2, class_3489.field_15557, 300);
        addFuel(map2, class_2246.field_40288, 300);
        addFuel(map2, class_3489.field_15534, 150);
        addFuel(map2, class_2246.field_40293, 150);
        addFuel(map2, class_3489.field_15550, 300);
        addFuel(map2, class_3489.field_15540, 300);
        addFuel(map2, class_3489.field_17620, 300);
        addFuel(map2, class_3489.field_40858, 300);
        addFuel(map2, class_2246.field_10179, 300);
        addFuel(map2, class_2246.field_10504, 300);
        addFuel(map2, class_2246.field_40276, 300);
        addFuel(map2, class_2246.field_16330, 300);
        addFuel(map2, class_2246.field_10223, 300);
        addFuel(map2, class_2246.field_10034, 300);
        addFuel(map2, class_2246.field_10380, 300);
        addFuel(map2, class_2246.field_9980, 300);
        addFuel(map2, class_2246.field_10429, 300);
        addFuel(map2, class_3489.field_15556, 300);
        addFuel(map2, class_1802.field_8102, 300);
        addFuel(map2, class_1802.field_8378, 300);
        addFuel(map2, class_2246.field_9983, 300);
        addFuel(map2, class_3489.field_15533, 200);
        addFuel(map2, class_3489.field_40108, 800);
        addFuel(map2, class_1802.field_8876, 200);
        addFuel(map2, class_1802.field_8091, 200);
        addFuel(map2, class_1802.field_8167, 200);
        addFuel(map2, class_1802.field_8406, 200);
        addFuel(map2, class_1802.field_8647, 200);
        addFuel(map2, class_3489.field_15552, 200);
        addFuel(map2, class_3489.field_15536, 1200);
        addFuel(map2, class_3489.field_15544, 100);
        addFuel(map2, class_3489.field_15555, 100);
        addFuel(map2, class_1802.field_8600, 100);
        addFuel(map2, class_3489.field_15528, 100);
        addFuel(map2, class_1802.field_8428, 100);
        addFuel(map2, class_3489.field_15542, 67);
        addFuel(map2, class_2246.field_10342, 4001);
        addFuel(map2, class_1802.field_8399, 300);
        addFuel(map2, class_2246.field_10211, 50);
        addFuel(map2, class_2246.field_10428, 100);
        addFuel(map2, class_2246.field_16492, 50);
        addFuel(map2, class_2246.field_10083, 300);
        addFuel(map2, class_2246.field_16328, 300);
        addFuel(map2, class_2246.field_16336, 300);
        addFuel(map2, class_2246.field_16331, 300);
        addFuel(map2, class_2246.field_16329, 300);
        addFuel(map2, class_2246.field_17563, 300);
        addFuel(map2, class_2246.field_28678, 100);
        addFuel(map2, class_2246.field_28679, 100);
        addFuel(map2, class_2246.field_37546, 300);
    }

    private static boolean isNonFlammableWood(class_1792 item) {
        return item.method_7854().method_31573(class_3489.field_23211);
    }

    private static void addFuel(Map<class_1792, Integer> map, class_6862<class_1792> tag, int fuelTime) {
        for(class_6880<class_1792> registryEntry : class_7923.field_41178.method_40286(tag)) {
            if (!isNonFlammableWood(registryEntry.comp_349())) {
                map.put(registryEntry.comp_349(), fuelTime);
            }
        }
    }

    private static void addFuel(Map<class_1792, Integer> map, class_1792 item, int fuelTime) {
        map.put(item, fuelTime);
    }

    private static void addFuel(Map<class_1792, Integer> map, class_2248 block, int fuelTime) {
        class_1792 item = block.method_8389();
        if (item != class_1802.field_8162) {
            map.put(item, fuelTime);
        }
    }

    public int getEnergyValue(class_1792 item, int maxProgress) {
        return (int) map2.getOrDefault(item, 0)/maxProgress;
    }
}
