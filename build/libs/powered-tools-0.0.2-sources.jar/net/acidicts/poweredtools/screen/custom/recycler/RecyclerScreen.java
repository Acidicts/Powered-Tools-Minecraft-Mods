package net.acidicts.poweredtools.screen.custom.recycler;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_757;
import net.acidicts.poweredtools.PoweredTools;
import net.acidicts.poweredtools.screen.renderer.EnergyInfoArea;
import net.acidicts.poweredtools.util.MouseUtil;
import java.util.Optional;

public class RecyclerScreen extends class_465<RecyclerScreenHandler> {
    private static final class_2960 GUI_TEXTURE =
            class_2960.method_60655(PoweredTools.MOD_ID, "textures/gui/recycler/recycler_gui.png");
    private static final class_2960 ARROW_TEXTURE =
            class_2960.method_60655(PoweredTools.MOD_ID, "textures/gui/arrow_progress.png");

    private EnergyInfoArea energyInfoArea;


    public RecyclerScreen(RecyclerScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        field_25268 = 1000;
        field_25270 = 1000;

        assignEnergyInfoArea();
    }

    private void assignEnergyInfoArea() {
        energyInfoArea = new EnergyInfoArea(((field_22789 - field_2792) / 2) + 156,
                ((field_22790 - field_2779) / 2 ) + 9, field_2797.blockEntity.energyStorage, 8, 48);
    }

    private void renderEnergyAreaTooltips(class_332 context, int pMouseX, int pMouseY, int x, int y) {
        if(isMouseAboveArea(pMouseX, pMouseY, x, y, 156, 9, 8, 48)) {
            context.method_51437(Screens.getTextRenderer(this), energyInfoArea.getTooltips(),
                    Optional.empty(), pMouseX - x, pMouseY - y);
        }
    }

    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        renderEnergyAreaTooltips(context, mouseX, mouseY, x, y);
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.setShaderTexture(0, GUI_TEXTURE);
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        context.method_25302(GUI_TEXTURE, x, y, 0, 0, field_2792, field_2779);

        energyInfoArea.draw(context);
        renderProgressArrow(context, x, y);
    }

    private void renderProgressArrow(class_332 context, int x, int y) {
        if(field_2797.isCrafting()) {
            context.method_25290(ARROW_TEXTURE, x + 73, y + 35, 0, 0,
                    field_2797.getScaledArrowProgress(), 16, 24, 16);
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);
        super.method_25394(context, mouseX, mouseY, delta);
        method_2380(context, mouseX, mouseY);
    }

    private boolean isMouseAboveArea(int pMouseX, int pMouseY, int x, int y, int offsetX, int offsetY, int width, int height) {
        return MouseUtil.isMouseOver(pMouseX, pMouseY, x + offsetX, y + offsetY, width, height);
    }
}