package net.acidicts.poweredtools.screen.custom.coal_generator;

import com.mojang.blaze3d.systems.RenderSystem;
import net.acidicts.poweredtools.PoweredTools;
import net.acidicts.poweredtools.screen.renderer.EnergyInfoArea;
import net.acidicts.poweredtools.util.MouseUtil;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_465;
import net.minecraft.class_757;
import java.util.Optional;

public class CoalGeneratorScreen extends class_465<CoalGeneratorScreenHandler> {
    private static final class_2960 GUI_TEXTURE =
            class_2960.method_60655(PoweredTools.MOD_ID, "textures/gui/coal_generator/coal_generator_gui.png");
    private static final class_2960 LIT_PROGRESS_TEXTURE = class_2960.method_60654("container/furnace/lit_progress");
    private EnergyInfoArea energyInfoArea;

    public CoalGeneratorScreen(CoalGeneratorScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        field_25267 = (field_22789 - field_2792) / 2;

        assignEnergyInfoArea();
    }

    private void assignEnergyInfoArea() {
        energyInfoArea = new EnergyInfoArea(((field_22789 - field_2792) / 2) + 156,
                ((field_22790 - field_2779) / 2 ) + 11, field_2797.blockEntity.energyStorage);
    }

    private void renderEnergyAreaTooltips(class_332 context, int pMouseX, int pMouseY, int x, int y) {
        if(isMouseAboveArea(pMouseX, pMouseY, x, y, 156, 11, 8, 64)) {
            context.method_51437(Screens.getTextRenderer(this), energyInfoArea.getTooltips(),
                    Optional.empty(), pMouseX - x, pMouseY - y);
        }
    }

    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        renderEnergyAreaTooltips(context, mouseX, mouseY, x, y);
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.setShaderTexture(0, GUI_TEXTURE);
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        context.method_25302(GUI_TEXTURE, x, y, 0, 0, field_2792, field_2779);

        energyInfoArea.draw(context);
        renderBurnProgress(context, x, y);
    }

    private void renderBurnProgress(class_332 context, int x, int y) {
        if(field_2797.isBurning()) {
            int l = class_3532.method_15386(this.field_2797.getFuelProgress() * 13.0f) + 1;
            context.method_52708(LIT_PROGRESS_TEXTURE, 14, 14, 0, 14 - l, x + 80, y + 18 + 14 - l, 14, l);
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);
        super.method_25394(context, mouseX, mouseY, delta);
        method_2380(context, mouseX, mouseY);
    }

    private boolean isMouseAboveArea(int pMouseX, int pMouseY, int x, int y, int offsetX, int offsetY, int width, int height) {
        return MouseUtil.isMouseOver(pMouseX, pMouseY, x + offsetX, y + offsetY, width, height);
    }
}