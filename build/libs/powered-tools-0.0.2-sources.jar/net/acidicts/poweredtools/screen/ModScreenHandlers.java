package net.acidicts.poweredtools.screen;

import net.acidicts.poweredtools.PoweredTools;
import net.acidicts.poweredtools.screen.custom.alloy_smelter.recycler.AlloySmelterScreenHandler;
import net.acidicts.poweredtools.screen.custom.coal_generator.CoalGeneratorScreenHandler;
import net.acidicts.poweredtools.screen.custom.recycler.RecyclerScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7923;

public class ModScreenHandlers {
    public static final class_3917<RecyclerScreenHandler> RECYCLER_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(PoweredTools.MOD_ID, "recycler_screen_handler"),
                    new ExtendedScreenHandlerType<>(RecyclerScreenHandler::new, class_2338.field_48404));

    public static final class_3917<CoalGeneratorScreenHandler> COAL_GENERATOR_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(PoweredTools.MOD_ID, "coal_generator_screen_handler"),
                    new ExtendedScreenHandlerType<>(CoalGeneratorScreenHandler::new, class_2338.field_48404));

    public static final class_3917<AlloySmelterScreenHandler> ALLOY_SMELTER_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(PoweredTools.MOD_ID, "alloy_smelter_screen_handler"),
                    new ExtendedScreenHandlerType<>(AlloySmelterScreenHandler::new, class_2338.field_48404));

    public static void registerScreenHandlers() {
        PoweredTools.LOGGER.info("Registering Screen Handlers for " + PoweredTools.MOD_ID);
    }
}
